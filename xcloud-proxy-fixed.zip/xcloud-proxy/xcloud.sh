#!/usr/bin/env bash
# xcloud.sh — Xbox Cloud Gaming through your own Linux machine.
#
# One file does everything: installs Node.js if needed, writes the app,
# makes an HTTPS certificate, and starts the server.
#
#   ./xcloud.sh                 run on port 8443 (HTTPS)
#   ./xcloud.sh 9000            run on another port
#   ./xcloud.sh --http          plain HTTP (only works when browsing on this machine)
#   ./xcloud.sh --password=XYZ  require a password to open it (or set ACCESS_PASSWORD)
#   sudo ./xcloud.sh --service  install as a service that starts on boot
#   sudo ./xcloud.sh --uninstall
#
# App files go in ./xcloud-app next to this script (override: XCLOUD_DIR=/path).
set -euo pipefail

NODE_VERSION="v22.12.0"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT_PATH="$SCRIPT_DIR/$(basename "${BASH_SOURCE[0]}")"
APP="${XCLOUD_DIR:-$SCRIPT_DIR/xcloud-app}"
PORT=""; TLS=1; SERVICE=0; UNINSTALL=0; ACCESS_PASSWORD="${ACCESS_PASSWORD:-}"

for arg in "$@"; do
  case "$arg" in
    --http) TLS=0 ;;
    --password=*) ACCESS_PASSWORD="${arg#--password=}" ;;
    --service) SERVICE=1 ;;
    --uninstall) UNINSTALL=1 ;;
    -h|--help) sed -n '2,14p' "$SCRIPT_PATH" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *[!0-9]*|'') echo "Unknown option: $arg (try --help)"; exit 1 ;;
    *) PORT="$arg" ;;
  esac
done
[ -n "$PORT" ] || { [ "$TLS" = 1 ] && PORT=8443 || PORT=8080; }

say()  { printf '\033[1;32m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m!!\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31mxx\033[0m %s\n' "$*"; exit 1; }
SUDO=""; [ "$(id -u)" -eq 0 ] || SUDO="$(command -v sudo || true)"

if [ "$UNINSTALL" = 1 ]; then
  [ "$(id -u)" -eq 0 ] || die "Run with sudo: sudo $0 --uninstall"
  systemctl disable --now xcloud 2>/dev/null || true
  rm -f /etc/systemd/system/xcloud.service && systemctl daemon-reload
  say "Service removed. App files are still in $APP (delete that folder to remove everything)."
  exit 0
fi

pkg_install() { # best effort across distros
  if command -v apt-get >/dev/null; then $SUDO apt-get update -qq && $SUDO apt-get install -y -qq "$@"
  elif command -v dnf >/dev/null; then $SUDO dnf install -y -q "$@"
  elif command -v pacman >/dev/null; then $SUDO pacman -Sy --noconfirm --needed "$@"
  elif command -v zypper >/dev/null; then $SUDO zypper -q install -y "$@"
  elif command -v apk >/dev/null; then $SUDO apk add -q "$@"
  else return 1; fi
}
fetch() { # url dest
  if command -v curl >/dev/null; then curl -fsSL "$1" -o "$2"
  elif command -v wget >/dev/null; then wget -q "$1" -O "$2"
  else pkg_install curl >/dev/null 2>&1 && curl -fsSL "$1" -o "$2"; fi
}

# ---------------------------------------------------------------- Node.js
NODE=""
for cand in "$APP/node/bin/node" "$(command -v node || true)"; do
  if [ -n "$cand" ] && [ -x "$cand" ] && [ "$("$cand" -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)" -ge 18 ]; then NODE="$cand"; break; fi
done
if [ -z "$NODE" ]; then
  case "$(uname -m)" in
    x86_64|amd64) ARCH=x64 ;;
    aarch64|arm64) ARCH=arm64 ;;
    armv7l|armv7*) ARCH=armv7l ;;
    *) die "No Node.js 18+ found and no prebuilt Node for $(uname -m). Install Node.js 18+ and rerun." ;;
  esac
  say "Downloading Node.js $NODE_VERSION ($ARCH)…"
  command -v tar >/dev/null && command -v xz >/dev/null || pkg_install tar xz-utils >/dev/null 2>&1 || pkg_install tar xz >/dev/null 2>&1 || true
  TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
  FILE="node-$NODE_VERSION-linux-$ARCH.tar.xz"
  fetch "https://nodejs.org/dist/$NODE_VERSION/$FILE" "$TMP/$FILE" || die "Download failed. Check the internet connection."
  fetch "https://nodejs.org/dist/$NODE_VERSION/SHASUMS256.txt" "$TMP/SHASUMS256.txt" || die "Checksum download failed."
  (cd "$TMP" && grep " $FILE\$" SHASUMS256.txt | sha256sum -c --status) || die "Node.js download failed its checksum. Not installing."
  mkdir -p "$APP/node"
  tar -xJf "$TMP/$FILE" -C "$APP/node" --strip-components=1
  NODE="$APP/node/bin/node"
fi
say "Using Node.js $("$NODE" -v)"

# ---------------------------------------------------------------- app files
say "Writing app to $APP"
mkdir -p "$APP/public/__sj"
cat > "$APP/server.js" <<'XCLOUD_FILE_END'
// Xbox Cloud Gaming proxy: serves the UI and relays HTTP / WebSocket traffic.
// No dependencies; needs Node 18+.
'use strict';
const http = require('http');
const https = require('https');
const net = require('net');
const tls = require('tls');
const fs = require('fs');
const path = require('path');
const SJ = require('./public/__sj/rewrite.js');

const crypto = require('crypto');
const PUBLIC = path.join(__dirname, 'public');
// Optional password lock (strongly recommended when hosted at a public link).
const PASSWORD = process.env.ACCESS_PASSWORD || '';
const AUTH_TOKEN = PASSWORD ? crypto.createHmac('sha256', PASSWORD).update('xcloud-auth').digest('hex') : '';
function authed(req) {
  if (!PASSWORD) return true;
  const m = /(?:^|;\s*)sjauth=([0-9a-f]+)/.exec(req.headers.cookie || '');
  return !!m && m[1].length === AUTH_TOKEN.length && crypto.timingSafeEqual(Buffer.from(m[1]), Buffer.from(AUTH_TOKEN));
}
const LOGIN_PAGE = (msg) => `<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Cloud Gaming</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0e0f10;color:#f1f3f4;font:15px system-ui,sans-serif;padding:16px}
form{width:min(340px,100%);display:grid;gap:12px}h1{font-size:22px;margin:0 0 4px}p{margin:0;color:#e57373;min-height:1em}
input,button{font:inherit;height:42px;border-radius:10px;border:1px solid #2a2d30;padding:0 14px}
input{background:#17191b;color:#f1f3f4}button{background:#107c10;color:#fff;border:0;font-weight:600;cursor:pointer}</style></head>
<body><form method="post" action="/__sj/login"><h1>Cloud Gaming</h1><input type="password" name="password" placeholder="Password" autofocus required>
<button>Unlock</button><p>${msg}</p></form></body></html>`;
// HTTPS if a certificate is configured (TLS_CERT/TLS_KEY, or certs/server.{crt,key}).
const TLS_CERT = process.env.TLS_CERT || path.join(__dirname, 'certs', 'server.crt');
const TLS_KEY = process.env.TLS_KEY || path.join(__dirname, 'certs', 'server.key');
const USE_TLS = process.env.NO_TLS !== '1' && fs.existsSync(TLS_CERT) && fs.existsSync(TLS_KEY);
const PORT = Number(process.env.PORT) || (USE_TLS ? 8443 : 8080);
// With HTTPS on, also serve plain HTTP for use on this machine: browsers treat
// http://localhost as secure, so no certificate has to be trusted there.
const LOCAL_PORT = USE_TLS ? (Number(process.env.LOCAL_PORT) || 8080) : 0;
const HOST = process.env.HOST || '0.0.0.0';
const STATIC = {
  '/': 'index.html',
  '/index.html': 'index.html',
  '/sw.js': 'sw.js',
  '/__sj/rewrite.js': '__sj/rewrite.js',
  '/__sj/client.js': '__sj/client.js',
};
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8' };

// Optional upstream proxy (UPSTREAM_PROXY=http://host:port), e.g. on networks
// that only allow outbound traffic through a proxy.
const UPSTREAM = process.env.UPSTREAM_PROXY ? new URL(process.env.UPSTREAM_PROXY) : null;
function tunnelSocket(host, port, cb) {
  const r = http.request({ host: UPSTREAM.hostname, port: UPSTREAM.port || 80, method: 'CONNECT', path: `${host}:${port}`, headers: { host: `${host}:${port}` } });
  r.once('connect', (res, sock) => (res.statusCode === 200 ? cb(null, sock) : (sock.destroy(), cb(new Error('upstream proxy refused ' + host + ': ' + res.statusCode)))));
  r.once('error', cb);
  r.end();
}
const upstreamAgent = UPSTREAM && new https.Agent({ keepAlive: true });
if (upstreamAgent) upstreamAgent.createConnection = (opts, cb) => {
  tunnelSocket(opts.host, opts.port || 443, (err, sock) => {
    if (err) return cb(err);
    const t = tls.connect({ socket: sock, servername: opts.servername || opts.host });
    t.once('secureConnect', () => cb(null, t));
    t.once('error', cb);
  });
};

// Big responses (Microsoft sign-in sets many large cookies) exceed Node's
// default 16 KB header limit, so allow much more.
const MAX_HEADER = 1024 * 1024;

// ---- Server-side cookie jar --------------------------------------------
// HttpOnly cookies (the large sign-in tokens, which page scripts can't read
// anyway) live here, keyed by a small per-browser session cookie, instead of
// riding along on every request the browser makes. Saved to data/ so a
// restart doesn't sign you out.
const DATA_DIR = process.env.XCLOUD_DATA || path.join(__dirname, 'data');
const JAR_FILE = path.join(DATA_DIR, 'cookies.json');
const SESSION_TTL = 60 * 24 * 3600 * 1000;
let jars = {};
try { jars = JSON.parse(fs.readFileSync(JAR_FILE, 'utf8')) || {}; } catch { jars = {}; }
let saveTimer = null;
function saveJars() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      const now = Date.now();
      for (const [sid, j] of Object.entries(jars)) {
        j.c = j.c.filter((c) => !c.exp || c.exp > now);
        if (now - j.t > SESSION_TTL) delete jars[sid];
      }
      fs.mkdirSync(DATA_DIR, { recursive: true });
      fs.writeFileSync(JAR_FILE + '.tmp', JSON.stringify(jars), { mode: 0o600 });
      fs.renameSync(JAR_FILE + '.tmp', JAR_FILE);
    } catch (e) { console.log('[cookies] could not save:', e.message); }
  }, 500);
}
function sessionOf(req) {
  const m = /(?:^|;\s*)sjsid=([0-9a-f]{32})(?:;|$)/.exec(req.headers.cookie || '');
  return m ? m[1] : null;
}
function newSession() { return crypto.randomBytes(16).toString('hex'); }
const sessionCookie = (sid, secure) => `sjsid=${sid}; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000${secure ? '; Secure' : ''}`;
function domainOk(host, c) { return c.hostOnly ? host === c.domain : host === c.domain || host.endsWith('.' + c.domain); }
function pathOk(reqPath, cp) { return reqPath === cp || reqPath.startsWith(cp.endsWith('/') ? cp : cp + '/'); }
function jarHeader(sid, target) {
  const j = sid && jars[sid];
  if (!j) return '';
  // (The Secure flag isn't enforced: targets are reached by this server, and
  // the browser-side cookies never enforced it either.)
  const now = Date.now(), host = target.hostname.toLowerCase();
  return j.c.filter((c) => (!c.exp || c.exp > now) && domainOk(host, c) && pathOk(target.pathname, c.path))
    .sort((a, b) => b.path.length - a.path.length)
    .map((c) => c.name + '=' + c.value).join('; ');
}
// Returns true if the cookie was taken into the server jar.
function jarStore(sid, str, target) {
  const parts = String(str).split(';');
  const first = parts.shift();
  const eq = first.indexOf('=');
  if (eq < 1) return false;
  const name = first.slice(0, eq).trim(), value = first.slice(eq + 1).trim();
  const host = target.hostname.toLowerCase();
  let domain = null, cpath = null, exp = null, maxAge = null, httpOnly = false, secure = false;
  for (const p of parts) {
    const t = p.trim(), k = t.indexOf('=');
    const an = (k < 0 ? t : t.slice(0, k)).toLowerCase(), av = k < 0 ? '' : t.slice(k + 1).trim();
    if (an === 'domain' && av) domain = av.replace(/^\./, '').toLowerCase();
    else if (an === 'path' && av.startsWith('/')) cpath = av;
    else if (an === 'expires') { const d = Date.parse(av); if (!isNaN(d)) exp = d; }
    else if (an === 'max-age') { const n = parseInt(av, 10); if (!isNaN(n)) maxAge = n; }
    else if (an === 'httponly') httpOnly = true;
    else if (an === 'secure') secure = true;
  }
  if (domain && !(host === domain || host.endsWith('.' + domain))) return true; // foreign domain: drop
  if (!cpath) { const dir = target.pathname.slice(0, target.pathname.lastIndexOf('/')); cpath = dir || '/'; }
  if (maxAge != null) exp = Date.now() + maxAge * 1000;
  const dom = domain || host;
  const j = jars[sid] || (jars[sid] = { t: Date.now(), c: [] });
  j.t = Date.now();
  const before = j.c.length;
  j.c = j.c.filter((c) => !(c.name === name && c.domain === dom && c.path === cpath));
  if (!httpOnly) { if (j.c.length !== before) saveJars(); return false; } // scripts need it: browser keeps it
  if (exp == null || exp > Date.now()) j.c.push({ name, value, domain: dom, hostOnly: !domain, path: cpath, exp, secure });
  if (j.c.length > 3000) j.c.splice(0, j.c.length - 3000);
  saveJars();
  return true;
}

const DROP_REQ = new Set(['host', 'connection', 'keep-alive', 'cookie', 'origin', 'referer', 'upgrade',
  'te', 'trailer', 'transfer-encoding', 'service-worker']);
const DROP_RES = new Set(['content-security-policy', 'content-security-policy-report-only', 'x-frame-options',
  'strict-transport-security', 'cross-origin-opener-policy', 'cross-origin-embedder-policy',
  'cross-origin-resource-policy', 'clear-site-data', 'alt-svc', 'connection', 'keep-alive', 'transfer-encoding',
  'link', 'location', 'report-to', 'nel', 'service-worker-allowed', 'set-cookie', 'permissions-policy',
  'origin-agent-cluster']);

// Shown if someone opens a /p/ URL before the service worker is installed.
const BOOT = `<!doctype html><meta charset="utf-8"><title>Loading…</title>
<p style="font:16px system-ui;margin:2rem">Starting proxy…</p>
<script>
navigator.serviceWorker.register('/sw.js', { scope: '/' })
  .then(() => navigator.serviceWorker.ready)
  .then(() => location.reload())
  .catch((e) => { document.body.textContent = 'Service workers are unavailable: ' + e; });
</script>`;

function serveStatic(res, file) {
  fs.readFile(path.join(PUBLIC, file), (err, data) => {
    if (err) { res.writeHead(404); res.end('Not found'); return; }
    const headers = { 'content-type': TYPES[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-cache' };
    if (file === 'sw.js') headers['service-worker-allowed'] = '/';
    res.writeHead(200, headers);
    res.end(data);
  });
}

function relay(req, res, u) {
  let target;
  try {
    target = new URL(u.searchParams.get('url'));
    if (!/^https?:$/.test(target.protocol)) throw new Error();
  } catch {
    res.writeHead(400, { 'content-type': 'text/plain' });
    res.end('Bad target URL');
    return;
  }
  const secure = !!req.socket.encrypted || req.headers['x-forwarded-proto'] === 'https';

  const headers = {};
  for (const [k, v] of Object.entries(req.headers)) {
    if (DROP_REQ.has(k) || k.startsWith('x-sj-') || k.startsWith('sec-fetch-') || k.startsWith('proxy-')) continue;
    headers[k] = v;
  }
  headers.host = target.host;
  let sid = sessionOf(req);
  const freshSession = !sid;
  if (!sid) sid = newSession();
  const cookie = [SJ.filterCookies(req.headers.cookie, target.hostname), jarHeader(sid, target)].filter(Boolean).join('; ');
  if (cookie) headers.cookie = cookie;
  const ref = req.headers['x-sj-referer'];
  if (ref) headers.referer = ref;
  if (req.headers['x-sj-origin']) headers.origin = req.headers['x-sj-origin'];
  const mode = req.headers['x-sj-fetch-mode'];
  if (mode) {
    headers['sec-fetch-site'] = req.headers['x-sj-fetch-site'] || 'none';
    headers['sec-fetch-mode'] = mode;
    headers['sec-fetch-dest'] = req.headers['x-sj-fetch-dest'] || 'empty';
    if (mode === 'navigate') headers['sec-fetch-user'] = '?1';
  }

  const mod = target.protocol === 'https:' ? https : http;
  // Buffer the (small) request body so the request can be retried.
  const chunks = [];
  req.on('data', (c) => chunks.push(c));
  req.on('end', () => send(Buffer.concat(chunks), 0));

  function send(body, family) {
  let answered = false;
  const up = mod.request({
    family: family || undefined,
    autoSelectFamily: family ? undefined : true,
    autoSelectFamilyAttemptTimeout: 500,
    hostname: target.hostname.replace(/^\[|\]$/g, ''),
    port: target.port || undefined,
    method: req.method,
    path: target.pathname + target.search,
    headers,
    servername: net.isIP(target.hostname) ? undefined : target.hostname,
    agent: upstreamAgent && target.protocol === 'https:' ? upstreamAgent : undefined,
    maxHeaderSize: MAX_HEADER,
  }, (upRes) => {
    answered = true;
    const out = {};
    for (const [k, v] of Object.entries(upRes.headers)) if (!DROP_RES.has(k)) out[k] = v;
    const setCookies = [];
    if (freshSession) setCookies.push(sessionCookie(sid, secure));
    for (const c of upRes.headers['set-cookie'] || []) {
      if (jarStore(sid, c, target)) {
        // Now held server-side; drop any old browser-side copy.
        const name = c.slice(0, c.indexOf('=')).trim();
        const stale = SJ.rewriteSetCookie(name + '=x', target.hostname, false);
        if (stale) { const key = stale.slice(0, stale.indexOf('=')); if ((req.headers.cookie || '').includes(key + '=')) setCookies.push(key + '=; Max-Age=0; Path=/'); }
      } else {
        const r = SJ.rewriteSetCookie(c, target.hostname, secure);
        if (r) setCookies.push(r);
      }
    }
    if (setCookies.length) out['set-cookie'] = setCookies;
    if (upRes.statusCode >= 500) console.log(`[relay] ${upRes.statusCode} ${req.method} ${target.href.slice(0, 200)}`);
    const status = upRes.statusCode;
    if (status >= 300 && status < 400 && upRes.headers.location) {
      // Fetch from the service worker would follow a real redirect itself,
      // so describe it in headers and let the worker issue a proxied redirect.
      let loc;
      try { loc = new URL(upRes.headers.location, target).href; } catch { loc = target.href; }
      delete out['content-length'];
      delete out['content-encoding'];
      out['x-sj-location'] = loc;
      out['x-sj-status'] = String(status);
      upRes.resume();
      res.writeHead(200, out);
      res.end();
      return;
    }
    res.writeHead(status, out);
    upRes.pipe(res);
  });
  up.setTimeout(family ? 15000 : 20000, () => up.destroy(Object.assign(new Error('upstream timeout'), { code: 'ETIMEDOUT' })));
  up.on('error', (err) => {
    // Some machines (often Linux on Chromebooks) get IPv6 addresses they
    // can't actually reach, and the connection just hangs: retry once over IPv4.
    const retryable = /ETIMEDOUT|ECONNRESET|EHOSTUNREACH|ENETUNREACH|EADDRNOTAVAIL/.test(err.code || '');
    if (!answered && !family && retryable && !res.headersSent) {
      console.log(`[relay] ${err.code} on ${target.host}; retrying over IPv4`);
      return send(body, 4);
    }
    console.log(`[relay] failed ${req.method} ${target.href.slice(0, 200)}: ${err.code || ''} ${err.message}`);
    if (err.code === 'ETIMEDOUT') {
      console.log(`[relay]   this machine can't get an answer from ${target.host}. Test it with:  curl -v -m 15 ${target.origin}/`);
    }
    if (!res.headersSent) res.writeHead(502, { 'content-type': 'text/plain', 'x-sj-error': encodeURIComponent(`${err.message} (this server couldn't reach ${target.host})`).slice(0, 300) });
    res.end('Upstream error: ' + err.message);
  });
  up.end(body);
  }
}

// WebSocket: rewrite the handshake, then splice raw bytes both ways. The
// browser's Sec-WebSocket-Key is forwarded untouched, so the target's
// Sec-WebSocket-Accept is valid for the browser and framing needs no help.
function tunnel(req, socket, head) {
  const u = new URL(req.url, 'http://x');
  let target;
  try {
    target = new URL(u.searchParams.get('url'));
    if (!/^wss?:$/.test(target.protocol)) throw new Error();
  } catch { socket.destroy(); return; }
  const origin = u.searchParams.get('origin') || target.origin.replace(/^ws/, 'http');
  const isTls = target.protocol === 'wss:';
  const port = Number(target.port) || (isTls ? 443 : 80);
  const host = target.hostname.replace(/^\[|\]$/g, '');
  const up = isTls
    ? tls.connect({ host, port, servername: net.isIP(host) ? undefined : host })
    : net.connect(port, host);

  up.once(isTls ? 'secureConnect' : 'connect', () => {
    const lines = [`GET ${target.pathname}${target.search} HTTP/1.1`, `Host: ${target.host}`, `Origin: ${origin}`];
    for (let i = 0; i < req.rawHeaders.length; i += 2) {
      const k = req.rawHeaders[i];
      const lk = k.toLowerCase();
      if (lk === 'host' || lk === 'origin' || lk === 'cookie' || lk.startsWith('sec-fetch-')) continue;
      lines.push(`${k}: ${req.rawHeaders[i + 1]}`);
    }
    const cookie = [SJ.filterCookies(req.headers.cookie, target.hostname), jarHeader(sessionOf(req), target)].filter(Boolean).join('; ');
    if (cookie) lines.push(`Cookie: ${cookie}`);
    up.write(lines.join('\r\n') + '\r\n\r\n');
    if (head && head.length) up.write(head);
    up.pipe(socket);
    socket.pipe(up);
  });
  up.on('error', () => socket.destroy());
  socket.on('error', () => up.destroy());
  socket.on('close', () => up.destroy());
}

function handler(req, res) {
  const u = new URL(req.url, 'http://x');
  if (PASSWORD && u.pathname === '/__sj/login' && req.method === 'POST') {
    let body = '';
    req.on('data', (d) => { body += d; if (body.length > 4096) req.destroy(); });
    req.on('end', () => {
      const given = new URLSearchParams(body).get('password') || '';
      const ok = crypto.createHmac('sha256', given).update('xcloud-auth').digest('hex') === AUTH_TOKEN;
      if (!ok) { res.writeHead(401, { 'content-type': 'text/html; charset=utf-8' }); res.end(LOGIN_PAGE('Wrong password')); return; }
      const secure = !!req.socket.encrypted || req.headers['x-forwarded-proto'] === 'https';
      res.writeHead(303, { location: '/', 'set-cookie': `sjauth=${AUTH_TOKEN}; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000${secure ? '; Secure' : ''}` });
      res.end();
    });
    return;
  }
  if (!authed(req)) {
    if (u.pathname === '/__sj/relay' || u.pathname === '/sw.js' || u.pathname.startsWith('/__sj/')) { res.writeHead(401); res.end('Locked'); return; }
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
    res.end(LOGIN_PAGE(''));
    return;
  }
  if (u.pathname === '/__sj/relay') return relay(req, res, u);
  if (u.pathname === '/__sj/clear' && req.method === 'POST') {
    // Sign out: expire every proxied cookie this browser holds.
    const sid = sessionOf(req);
    if (sid && jars[sid]) { delete jars[sid]; saveJars(); }
    const names = String(req.headers.cookie || '').split(/;\s*/).map((c) => c.split('=')[0]).filter((n) => n && n !== 'sjauth' && n !== 'sjsid');
    res.writeHead(200, { 'content-type': 'application/json', 'set-cookie': names.map((n) => `${n}=; Max-Age=0; Path=/`) });
    res.end(JSON.stringify({ cleared: names.length }));
    return;
  }
  if (STATIC[u.pathname]) return serveStatic(res, STATIC[u.pathname]);
  if (u.pathname === '/ca.crt' && USE_TLS) {
    // The public CA certificate, so other devices can install it easily.
    return fs.readFile(path.join(path.dirname(TLS_CERT), 'ca.crt'), (err, data) => {
      if (err) { res.writeHead(404); res.end('No CA certificate'); return; }
      res.writeHead(200, { 'content-type': 'application/x-x509-ca-cert', 'content-disposition': 'attachment; filename="ca.crt"' });
      res.end(data);
    });
  }
  if (u.pathname.startsWith(SJ.PREFIX)) {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
    res.end(BOOT);
    return;
  }
  res.writeHead(404, { 'content-type': 'text/plain' });
  res.end('Not found');
}

const server = USE_TLS
  ? https.createServer({ cert: fs.readFileSync(TLS_CERT), key: fs.readFileSync(TLS_KEY), maxHeaderSize: MAX_HEADER }, handler)
  : http.createServer({ maxHeaderSize: MAX_HEADER }, handler);
const localServer = LOCAL_PORT ? http.createServer({ maxHeaderSize: MAX_HEADER }, handler) : null;
function onUpgrade(req, socket, head) {
  if (!authed(req)) { socket.destroy(); return; }
  if (new URL(req.url, 'http://x').pathname === '/__sj/ws') tunnel(req, socket, head);
  else socket.destroy();
}
server.on('upgrade', onUpgrade);
if (localServer) localServer.on('upgrade', onUpgrade);

if (require.main === module) {
  const ips = Object.values(require('os').networkInterfaces()).flat()
    .filter((a) => a && a.family === 'IPv4' && !a.internal).map((a) => a.address);
  const started = () => {
    console.log(`Xbox Cloud Gaming proxy v2026.11.16 running` + (PASSWORD ? ' (password protected)' : ''));
    if (USE_TLS) {
      if (localServer && localServer.listening) console.log(`  on this machine: http://localhost:${LOCAL_PORT}   <- use this here, no certificate needed`);
      else console.log(`  on this machine: https://localhost:${PORT}`);
      for (const ip of ips) console.log(`  other devices:   https://${ip}:${PORT}   (they must trust ca.crt)`);
    } else {
      console.log(`  on this machine: http://localhost:${PORT}`);
      for (const ip of ips) console.log(`  other devices:   http://${ip}:${PORT}   (won't work: needs HTTPS; run xcloud.sh without --http)`);
    }
  };
  server.listen(PORT, HOST, () => {
    if (!localServer) return started();
    localServer.once('error', (e) => { console.log(`  (couldn't open http port ${LOCAL_PORT}: ${e.code}; set LOCAL_PORT to another port)`); started(); });
    localServer.listen(LOCAL_PORT, HOST, started);
  });
}
module.exports = server;
XCLOUD_FILE_END
cat > "$APP/public/index.html" <<'XCLOUD_FILE_END'
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0e0f10">
<title>Cloud Gaming</title>
<style>
  :root { --bg: #0e0f10; --bar: #17191b; --fg: #f1f3f4; --muted: #9ba1a6; --hover: #2a2d30; --green: #107c10; --green-hi: #1a9a1a; }
  * { box-sizing: border-box; }
  html, body { margin: 0; height: 100%; overflow: hidden; background: var(--bg); color: var(--fg);
               font: 14px/1.4 system-ui, -apple-system, "Segoe UI", Roboto, Ubuntu, sans-serif; }
  button { font: inherit; color: inherit; background: none; border: 0; cursor: pointer; }
  svg { width: 18px; height: 18px; fill: none; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; flex: none; }

  #bar { position: fixed; top: 0; left: 0; right: 0; height: 44px; z-index: 3; display: flex; align-items: center; gap: 2px;
         padding: 0 8px; background: var(--bar); border-bottom: 1px solid #000; transition: transform .2s ease; }
  #brand { display: flex; align-items: center; gap: 8px; padding: 0 10px 0 6px; font-weight: 600; letter-spacing: .01em; white-space: nowrap; }
  #brand i { width: 22px; height: 22px; border-radius: 50%; background: var(--green); display: grid; place-items: center; }
  #brand i svg { width: 14px; height: 14px; color: #fff; }
  .b { height: 32px; min-width: 32px; padding: 0 8px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; gap: 6px; color: var(--fg); }
  .b:hover { background: var(--hover); }
  .b span { font-size: 13px; color: var(--muted); }
  .b:hover span { color: var(--fg); }
  #where { flex: 1; min-width: 0; text-align: center; color: var(--muted); font-size: 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; padding: 0 8px; }
  #progress { position: absolute; left: 0; bottom: -1px; height: 2px; width: 0; background: var(--green-hi); transition: width .3s ease, opacity .4s; opacity: 0; }
  #progress.on { opacity: 1; width: 70%; transition: width 6s cubic-bezier(.1,.7,.2,1); }
  #progress.done { opacity: 0; width: 100%; }

  #game { position: fixed; top: 44px; left: 0; width: 100%; height: calc(100% - 44px); border: 0; background: var(--bg); z-index: 1; }

  /* Immersive mode: bar slides away; it comes back when the mouse touches the top edge. */
  body.immersive #bar { transform: translateY(-100%); }
  body.immersive.reveal #bar { transform: none; }
  body.immersive #game { top: 0; height: 100%; }
  #edge { position: fixed; top: 0; left: 0; right: 0; height: 6px; z-index: 4; display: none; }
  body.immersive #edge { display: block; }

  .overlay { position: fixed; inset: 0; z-index: 5; display: none; place-items: center; background: var(--bg); padding: 16px; text-align: center; }
  .overlay.show { display: grid; }
  .card { max-width: 480px; }
  .card h2 { margin: 0 0 8px; font-size: 22px; font-weight: 600; }
  .card p { margin: 0 0 20px; color: var(--muted); font-size: 15px; }
  .card code { background: var(--hover); padding: 1px 6px; border-radius: 4px; color: var(--fg); }
  .primary { height: 40px; padding: 0 20px; border-radius: 20px; background: var(--green); color: #fff; font-weight: 600; }
  .primary:hover { background: var(--green-hi); }
  .spin { width: 36px; height: 36px; margin: 0 auto 16px; border-radius: 50%; border: 3px solid var(--hover); border-top-color: var(--green-hi); animation: s .8s linear infinite; }
  @keyframes s { to { transform: rotate(360deg); } }

  #probBtn { display: none; color: #ffb74d; }
  #probBtn.show { display: inline-flex; }
  #probBtn b { font-size: 12px; background: #ffb74d; color: #111; border-radius: 9px; padding: 0 6px; line-height: 18px; }
  #probs { position: fixed; top: 52px; right: 8px; width: min(560px, calc(100% - 16px)); max-height: min(70vh, 560px); z-index: 6;
           display: none; flex-direction: column; background: var(--bar); border: 1px solid #2f3336; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,.5); }
  #probs.show { display: flex; }
  #probs header { display: flex; align-items: center; gap: 8px; padding: 10px 12px; border-bottom: 1px solid #2f3336; }
  #probs header strong { flex: 1; }
  #probs ol { margin: 0; padding: 4px 0; overflow: auto; list-style: none; font: 12px/1.45 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }
  #probs li { padding: 6px 12px; border-bottom: 1px solid #222; word-break: break-all; color: var(--muted); }
  #probs li em { font-style: normal; color: #ffb74d; }
  #probs li span { color: var(--fg); }
  #probs p { margin: 0; padding: 10px 12px; color: var(--muted); font-size: 13px; }
  @media (max-width: 640px) { .b span, #where { display: none; } }
</style>
</head>
<body>
<div id="edge"></div>
<div id="bar">
  <div id="brand" title="Cloud Gaming proxy, version 2026.11.16 (leave-page prompt)"><i><svg viewBox="0 0 24 24"><path d="M8 5l8 7-8 7z" fill="currentColor" stroke="none"/></svg></i>Cloud Gaming<small style="font-weight:400;color:var(--muted);font-size:11px;margin-left:6px">v2026.11.16</small></div>
  <button class="b" id="back" title="Back (Alt+Left)" aria-label="Back"><svg viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></button>
  <button class="b" id="reload" title="Reload (F5)" aria-label="Reload"><svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 1 1-2.64-6.36L21 8"/><path d="M21 3v5h-5"/></svg></button>
  <button class="b" id="home" title="Cloud Gaming home" aria-label="Home"><svg viewBox="0 0 24 24"><path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/></svg><span>Home</span></button>
  <div id="where"></div>
  <button class="b" id="probBtn" title="Problems seen on this page" aria-label="Problems"><svg viewBox="0 0 24 24"><path d="M12 3l10 18H2z"/><path d="M12 10v4M12 17.5h.01"/></svg><b id="probCount">0</b></button>
  <button class="b" id="signout" title="Sign out and clear saved data on this server" aria-label="Sign out"><svg viewBox="0 0 24 24"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l-5-5 5-5M5 12h11"/></svg><span>Sign out</span></button>
  <button class="b" id="fs" title="Full screen (F11)" aria-label="Full screen"><svg viewBox="0 0 24 24"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg><span>Full screen</span></button>
  <div id="progress"></div>
</div>

<iframe id="game" title="Xbox Cloud Gaming"
  allow="fullscreen; gamepad; autoplay; clipboard-read; clipboard-write; microphone; keyboard-map; screen-wake-lock"
  allowfullscreen></iframe>

<div id="probs" role="dialog" aria-label="Problems">
  <header><strong>Problems</strong>
    <button class="b" id="probCopy"><span>Copy</span></button>
    <button class="b" id="probClear"><span>Clear</span></button>
    <button class="b" id="probClose" aria-label="Close"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
  </header>
  <p>If something isn't working, press Copy and send this list to whoever is helping you.</p>
  <ol id="probList"></ol>
</div>

<div class="overlay show" id="start"><div class="card"><div class="spin"></div><p>Starting…</p></div></div>
<div class="overlay" id="error"><div class="card"><h2 id="errTitle"></h2><p id="errMsg"></p></div></div>
<div class="overlay" id="offsite"><div class="card">
  <h2>That page isn't part of Cloud Gaming</h2>
  <p id="offsiteMsg">This app only opens Xbox Cloud Gaming and Microsoft sign-in.</p>
  <button class="primary" id="offsiteBack">Back to Cloud Gaming</button>
</div></div>

<script>
(() => {
  'use strict';
  const PREFIX = '/p/';
  const HOME = 'https://play.xbox.com/';
  // Sites the app may show. Everything a page loads in the background
  // (scripts, APIs, captchas) is still allowed; this only limits what the
  // main view navigates to.
  const ALLOWED = ['xbox.com', 'xboxlive.com', 'xboxservices.com', 'live.com', 'live.net', 'microsoft.com',
    'microsoftonline.com', 'msauth.net', 'msftauth.net', 'gfx.ms', 'windows.net', 'arkoselabs.com', 'hcaptcha.com',
    'microsoftstore.com'];
  const $ = (id) => document.getElementById(id);
  const frame = $('game');
  let lastGood = HOME, loading = false;

  const allowed = (url) => {
    try { const h = new URL(url).hostname; return ALLOWED.some((d) => h === d || h.endsWith('.' + d)); } catch { return false; }
  };
  const decode = (href) => {
    try {
      const u = new URL(href);
      if (u.origin === location.origin && u.pathname.startsWith(PREFIX)) return u.href.slice(u.origin.length + PREFIX.length);
    } catch {}
    return null;
  };

  function go(url) {
    $('offsite').classList.remove('show');
    setLoading(true);
    frame.src = PREFIX + url;
  }
  function setLoading(on) {
    loading = on;
    const p = $('progress');
    if (on) { p.className = ''; void p.offsetWidth; p.className = 'on'; }
    else { p.className = 'done'; }
  }

  // Track where the view is (also catches single-page-app navigations).
  function check() {
    let url = null, title = '';
    try { url = decode(frame.contentWindow.location.href); title = frame.contentDocument.title; } catch {}
    if (!url) return;
    if (allowed(url)) {
      lastGood = url;
      $('offsite').classList.remove('show');
      $('where').textContent = new URL(url).hostname + (title ? ' — ' + title : '');
      document.title = title ? title + ' · Cloud Gaming' : 'Cloud Gaming';
    } else if (!$('offsite').classList.contains('show')) {
      $('offsiteMsg').textContent = new URL(url).hostname + ' is outside Xbox Cloud Gaming, so it isn’t shown here.';
      $('offsite').classList.add('show');
    }
  }
  frame.addEventListener('load', () => { setLoading(false); check(); hookKeys(); });
  setInterval(check, 500);

  // ---- problems panel
  const problems = [];
  function addProblem(p) {
    const line = `${new Date().toLocaleTimeString()}  ${p.kind === 'request' ? (p.method || '') + ' ' + p.status : 'page error'}  ${p.url || ''}  ${p.detail || ''}`;
    if (problems.length && problems[problems.length - 1].line === line) return;
    problems.push({ ...p, line });
    if (problems.length > 200) problems.shift();
    $('probCount').textContent = problems.length;
    $('probBtn').classList.add('show');
    const li = document.createElement('li');
    const em = document.createElement('em'); em.textContent = p.kind === 'request' ? 'request ' + p.status : 'page error';
    const sp = document.createElement('span'); sp.textContent = ' ' + (p.detail || '');
    li.append(em, sp, document.createTextNode(' \u2014 ' + (p.url || '').slice(0, 300)));
    $('probList').appendChild(li);
  }
  navigator.serviceWorker && navigator.serviceWorker.addEventListener('message', (e) => { if (e.data && e.data.sjDiag) addProblem(e.data.sjDiag); });
  $('probBtn').onclick = () => $('probs').classList.toggle('show');
  $('probClose').onclick = () => $('probs').classList.remove('show');
  $('probClear').onclick = () => { problems.length = 0; $('probList').textContent = ''; $('probBtn').classList.remove('show'); $('probs').classList.remove('show'); };
  $('probCopy').onclick = async () => {
    const text = 'Cloud Gaming problems (' + navigator.userAgent + ')\n' + problems.map((p) => p.line).join('\n');
    try { await navigator.clipboard.writeText(text); $('probCopy').firstChild.textContent = 'Copied'; }
    catch { prompt('Copy this:', text); }
    setTimeout(() => { $('probCopy').firstChild.textContent = 'Copy'; }, 1500);
  };

  // Proxied pages call these: new-window links stay in this view; errors go to the panel.
  window.__sjShell = {
    openTab(url) { if (allowed(url)) go(url); return frame.contentWindow; },
    report: addProblem,
  };

  // ---- controls
  const win = () => frame.contentWindow;
  function back() { try { win().history.back(); } catch {} }
  function reload() { setLoading(true); try { win().location.reload(); } catch { go(lastGood); } }
  function fullscreen() {
    if (document.fullscreenElement) document.exitFullscreen();
    else document.documentElement.requestFullscreen().catch(() => {});
  }
  $('back').onclick = back;
  $('reload').onclick = reload;
  $('home').onclick = () => go(HOME);
  $('fs').onclick = fullscreen;
  $('offsiteBack').onclick = () => go(lastGood);
  $('signout').onclick = async () => {
    if (!confirm('Sign out of Xbox and clear the saved sign-in on this server?')) return;
    try { await fetch('/__sj/clear', { method: 'POST' }); } catch {}
    try { localStorage.clear(); sessionStorage.clear(); } catch {}
    try { for (const k of await caches.keys()) await caches.delete(k); } catch {}
    go(HOME);
  };

  document.addEventListener('fullscreenchange', () => {
    document.body.classList.toggle('immersive', document.fullscreenElement === document.documentElement);
  });
  $('edge').addEventListener('mouseenter', () => document.body.classList.add('reveal'));
  $('bar').addEventListener('mouseleave', () => document.body.classList.remove('reveal'));

  function onKey(e) {
    const k = e.key, mod = e.ctrlKey || e.metaKey;
    let handled = true;
    if (k === 'F5' || (mod && k.toLowerCase() === 'r')) reload();
    else if (k === 'F11') fullscreen();
    else if (e.altKey && k === 'ArrowLeft') back();
    else if (e.altKey && k.toLowerCase() === 'h') go(HOME);
    else handled = false;
    if (handled) { e.preventDefault(); e.stopPropagation(); }
  }
  document.addEventListener('keydown', onKey, true);

  // Ask before closing or leaving the tab. Browsers show their own fixed
  // wording ("Leave site? Changes you made may not be saved.") and only
  // after the page has been clicked or typed in.
  window.addEventListener('beforeunload', (e) => {
    e.preventDefault();
    e.returnValue = '';
    return '';
  });
  function hookKeys() {
    try { const w = win(); if (!w.__sjKeys) { w.__sjKeys = true; w.addEventListener('keydown', onKey, true); } } catch {}
  }

  // ---- start
  function fail(title, msg) {
    $('start').classList.remove('show');
    $('errTitle').textContent = title;
    $('errMsg').innerHTML = msg;
    $('error').classList.add('show');
  }
  if (!window.isSecureContext || !('serviceWorker' in navigator)) {
    fail('Open this with https://',
      'Cloud Gaming needs a secure connection. Use the <code>https://</code> address that <code>xcloud.sh</code> printed, ' +
      'and make sure this device trusts the certificate (the script shows how).');
    return;
  }
  navigator.serviceWorker.register('/sw.js', { scope: '/' })
    .then(() => navigator.serviceWorker.ready)
    .then(() => {
      $('start').classList.remove('show');
      const want = new URLSearchParams(location.search).get('url');
      go(want && allowed(want) ? want : HOME);
    })
    .catch((e) => {
      const local = /^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname);
      fail('Couldn’t start', String(e && e.message || e) + '<br><br>' + (local && location.protocol === 'https:'
        ? 'On the machine running the server, open <a style="color:#6fdc6f" href="http://localhost:8080">http://localhost:8080</a> instead. It needs no certificate.'
        : 'This device has to trust the server’s certificate. Download <a style="color:#6fdc6f" href="/ca.crt">ca.crt</a> and install it as a trusted root authority (the script shows how).'));
    });
})();
</script>
</body>
</html>
XCLOUD_FILE_END
cat > "$APP/public/sw.js" <<'XCLOUD_FILE_END'
/* Service worker: routes every request made by a proxied page through the relay. */
importScripts('/__sj/rewrite.js');

const { PREFIX } = self.SJ;
// Injected at the top of every proxied page (client.js removes these tags
// again after running so the DOM matches the server's HTML). The import map
// makes root-relative module paths ("/assets/x.js") resolve straight to the
// proxied URL. Without it they'd arrive via a redirect, and browsers key
// modules by the requested URL, so one module could load and run twice.
function inject(target) {
  // Already-proxied URLs map to themselves. The keys end in "//" so the rest
  // resolves as a relative path (import maps reject mappings that escape).
  const map = { imports: { '/': PREFIX + target.origin + '/', [PREFIX + 'https://']: PREFIX + 'https://', [PREFIX + 'http://']: PREFIX + 'http://', '/__sj/': '/__sj/' } };
  return '<script type="importmap" data-sj="">' + JSON.stringify(map).replace(/</g, '\\u003c') + '</script>' +
    '<script src="/__sj/rewrite.js" data-sj=""></script><script src="/__sj/client.js" data-sj=""></script>';
}
const NULL_BODY = new Set([101, 103, 204, 205, 304]);
const REDIRECTS = new Set([301, 302, 303, 307, 308]);
const PRELUDE = '(' + self.SJ.install.toString() + ')(self);\n';

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

// Problems are shown in the app's "Problems" panel (analytics noise is skipped).
const NOISE = /events\.data\.microsoft|browser\.pipe\.aria|sentry\.io|fpt\.live\.com|clarity\.ms|demdex\.net|omtrdc\.net|doubleclick|google-analytics/;
function report(entry) {
  if (NOISE.test(entry.url || '')) return;
  self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((cs) => {
    for (const c of cs) if (!new URL(c.url).pathname.startsWith(PREFIX)) c.postMessage({ sjDiag: entry });
  });
}

self.addEventListener('fetch', (e) => {
  e.respondWith(route(e).catch((err) => {
    report({ kind: 'request', status: 'failed', url: e.request.url, detail: String(err && err.message || err) });
    return new Response('Proxy error: ' + (err && err.message || err), { status: 502, headers: { 'content-type': 'text/plain' } });
  }));
});

// Target URL for a proxy-origin URL, or null.
function targetOf(str) {
  try {
    const u = new URL(str);
    if (u.origin !== self.location.origin || !u.pathname.startsWith(PREFIX)) return null;
    let rest = u.href.slice(u.origin.length + PREFIX.length);
    if (!/^[a-z][\w+.-]*:/i.test(rest)) rest = 'https://' + rest;
    const t = new URL(rest);
    return /^https?:$/.test(t.protocol) ? t : null;
  } catch { return null; }
}

// The target URL of the page (or worker) that issued this request.
async function requesterTarget(e) {
  if (e.clientId) {
    const c = await self.clients.get(e.clientId);
    if (c) { const t = targetOf(c.url); if (t) return t; }
  }
  return e.request.referrer ? targetOf(e.request.referrer) : null;
}

// Xbox sends its own crash reports (Sentry) and telemetry exceptions
// (Microsoft 1DS). They pass through here, so read them and show the errors
// in the Problems panel: errors caught by the app's own "Something went
// wrong" screens never reach the page's error events.
const CRASH_REPORT = /(^|\.)ingest(\.[a-z]+)?\.sentry\.io$|^browser\.events\.data\.microsoft\.com$|^[a-z0-9-]+\.events\.data\.microsoft\.com$/;
function readCrashReports(target, req, pageUrl) {
  if (req.method !== 'POST' || !CRASH_REPORT.test(target.hostname)) return;
  req.clone().text().then((text) => {
    for (const line of text.split('\n')) {
      let o;
      try { o = JSON.parse(line); } catch { continue; }
      if (o && o.exception && Array.isArray(o.exception.values)) {
        for (const v of o.exception.values) {
          const frames = ((v.stacktrace && v.stacktrace.frames) || []).slice(-4).reverse()
            .map((f) => `${f.function || '?'} ${String(f.filename || '').split('/').pop()}:${f.lineno || '?'}`).join(' < ');
          report({ kind: 'error', url: (o.request && o.request.url) || pageUrl, detail: `[crash report] ${v.type || 'Error'}: ${v.value || ''}${frames ? ' | ' + frames : ''}` });
        }
      } else if (o && typeof o.name === 'string' && /exception|error|fail/i.test(o.name) && !/performance/i.test(o.name)) {
        const d = summarizeTelemetry(o.data || o.baseData || {});
        if (d) report({ kind: 'error', url: pageUrl, detail: '[telemetry] ' + d });
      }
    }
  }).catch(() => {});
}

// Keep what explains an error; drop the fields every event repeats.
const TELEMETRY_BOILERPLATE = new Set(['webAppVersion', 'webAppSessionId', 'isWebServer', 'activeUserXuid', 'route',
  'webFlightRing', 'deviceId', 'infraHost', 'density', 'level', 'timestamp']);
function summarizeTelemetry(d) {
  if (typeof d === 'string') { try { d = JSON.parse(d); } catch { return d.slice(0, 1500); } }
  const msg = String(d.message || '');
  if (/^No transformed data for query key/.test(msg)) return ''; // follow-on noise
  const out = [];
  if (d.errorType) out.push(d.errorType);
  if (msg) out.push(msg);
  if (d.context && d.context.tag) out.push('in ' + d.context.tag);
  const rest = {};
  for (const [k, v] of Object.entries(d)) {
    if (TELEMETRY_BOILERPLATE.has(k) || k === 'errorType' || k === 'message') continue;
    if (k === 'context' && v && typeof v === 'object') {
      const c = { ...v }; delete c.tag; delete c.timestamp;
      if (Object.keys(c).length) rest.context = c;
      continue;
    }
    rest[k] = v;
  }
  if (Object.keys(rest).length) out.push(JSON.stringify(rest).replace(/\\n/g, ' ').slice(0, 1500));
  return out.join(' | ');
}

async function route(e) {
  const req = e.request;
  const url = new URL(req.url);
  const same = url.origin === self.location.origin;

  if (same) {
    if (url.pathname.startsWith(PREFIX)) {
      const t = targetOf(req.url);
      if (!t) return new Response('Bad proxied URL', { status: 400 });
      return proxy(e, req, t);
    }
    if (url.pathname.startsWith('/__sj/') || url.pathname === '/sw.js') return fetch(req);
  } else if (!/^https?:$/.test(url.protocol)) {
    return fetch(req);
  }

  // Not a /p/ URL. If a proxied page asked for it, it escaped rewriting.
  const from = await requesterTarget(e);
  if (!from) return fetch(req);
  if (same) {
    // Root-relative URL like /api: re-root it on the target's origin.
    return Response.redirect(PREFIX + new URL(url.pathname + url.search, from.origin).href, 307);
  }
  return proxy(e, req, url, from); // absolute cross-origin subresource
}

function site(host) { return host.split('.').slice(-2).join('.'); }

async function proxy(e, req, target, from) {
  if (from === undefined) from = await requesterTarget(e);
  readCrashReports(target, req, from ? from.href : '');
  const headers = new Headers(req.headers);

  // Referer, as the default strict-origin-when-cross-origin policy would send it.
  let ref = null;
  if (req.referrer) {
    ref = targetOf(req.referrer);
    if (!ref) { const r = new URL(req.referrer); if (r.origin !== self.location.origin) ref = r; }
  }
  if (ref) headers.set('x-sj-referer', ref.origin === target.origin ? ref.href : ref.origin + '/');

  // Origin header: browsers send it on every non-GET/HEAD request and on
  // cross-origin CORS requests. Through the proxy everything is same-origin,
  // so reconstruct it from the requesting page.
  const initiator = from || ref;
  if (initiator) {
    const o = initiator.origin;
    if ((req.method !== 'GET' && req.method !== 'HEAD') || (req.mode === 'cors' && o !== target.origin)) headers.set('x-sj-origin', o);
  }

  // Sec-Fetch-* as the browser would have sent them to the real site.
  let fetchSite = 'none';
  if (initiator) fetchSite = initiator.origin === target.origin ? 'same-origin' : site(initiator.hostname) === site(target.hostname) ? 'same-site' : 'cross-site';
  headers.set('x-sj-fetch-site', fetchSite);
  headers.set('x-sj-fetch-mode', req.mode === 'navigate' ? 'navigate' : req.mode);
  headers.set('x-sj-fetch-dest', req.destination || 'empty');

  const init = {
    method: req.method,
    headers,
    credentials: 'same-origin',
    redirect: 'manual',
    cache: req.cache === 'only-if-cached' ? 'default' : req.cache,
  };
  if (req.method !== 'GET' && req.method !== 'HEAD') init.body = await req.arrayBuffer();

  const res = await fetch('/__sj/relay?url=' + encodeURIComponent(target.href), init);
  // Trace every sign-in / token request, successful or not, so the
  // Problems panel shows whether the token exchange happens at all.
  if (/(^|\.)auth\.xboxlive\.com$|^sisu\.xboxlive\.com$|^title\.mgt\.xboxlive\.com$/.test(target.hostname) ||
      (/^login\.(live|microsoftonline)\.com$/.test(target.hostname) && /token/i.test(target.pathname))) {
    let note = '';
    if (res.status >= 400) {
      try { note = ' \u2014 ' + (await res.clone().text()).replace(/\s+/g, ' ').slice(0, 300); } catch { /* ignore */ }
      const xerr = res.headers.get('x-err') || res.headers.get('www-authenticate');
      if (xerr) note += ` [${xerr.slice(0, 120)}]`;
    }
    report({ kind: 'request', status: res.status, method: req.method, url: target.origin + target.pathname, detail: '[sign-in trace]' + note });
  }
  // Report server errors, and 4xx answers to the app's own API calls
  // (fetch/XHR), with the start of the reply: that usually names the reason.
  const apiCall = req.mode !== 'navigate' && !req.destination;
  const frameLoad = req.destination === 'iframe' || req.destination === 'frame';
  if (res.status >= 500 || res.status === 431 || res.status === 413 || ((apiCall || frameLoad) && res.status >= 400)) {
    const why = res.headers.get('x-sj-error');
    let detail = why ? decodeURIComponent(why) : res.statusText;
    if (!why) {
      try {
        const body = (await res.clone().text()).replace(/\s+/g, ' ').trim();
        if (body) detail += ' \u2014 ' + body.slice(0, 240);
      } catch { /* unreadable body */ }
      const hints = ['www-authenticate', 'x-err', 'x-error', 'ms-cv', 'x-ms-error-code'];
      for (const h of hints) { const v = res.headers.get(h); if (v) detail += ` [${h}: ${v.slice(0, 120)}]`; }
    }
    report({ kind: 'request', status: res.status, method: req.method, url: target.href, detail });
  }

  const loc = res.headers.get('x-sj-location');
  if (loc) {
    const st = Number(res.headers.get('x-sj-status'));
    return Response.redirect(PREFIX + new URL(loc, target).href, REDIRECTS.has(st) ? st : 302);
  }

  const out = new Headers(res.headers);
  for (const k of [...out.keys()]) if (k.startsWith('x-sj-')) out.delete(k);
  // The browser already decoded the body, so the encoding and the encoded
  // length no longer apply. Some apps (Xbox's HTTP client) treat a body with
  // neither Content-Length nor Content-Type as empty, so a correct length is
  // put back below wherever it can be known.
  const wasEncoded = !!out.get('content-encoding');
  const origLength = out.get('content-length');
  out.delete('content-encoding');
  out.delete('content-length');
  const meta = { status: res.status, statusText: res.statusText, headers: out };

  if (NULL_BODY.has(res.status) || req.method === 'HEAD') return new Response(null, meta);

  const type = (out.get('content-type') || '').toLowerCase();
  const dest = req.destination;
  let kind = null;
  if (type.includes('text/html') && (req.mode === 'navigate' || ['document', 'iframe', 'frame', 'embed', 'object'].includes(dest))) kind = 'html';
  else if (['script', 'worker', 'sharedworker'].includes(dest)) kind = 'js';
  if (!kind) {
    if (!out.has('content-type')) {
      // Typically a small API reply (e.g. Xbox's endpoint directory):
      // buffer it so the exact decoded length can be given.
      const buf = await res.arrayBuffer();
      out.set('content-length', String(buf.byteLength));
      return new Response(buf, meta);
    }
    if (origLength != null && !wasEncoded) out.set('content-length', origLength);
    return new Response(res.body, meta);
  }

  const charset = (/charset=["']?([^;"']+)/.exec(type) || [])[1] || 'utf-8';
  let decoder;
  try { decoder = new TextDecoder(charset); } catch { decoder = new TextDecoder('utf-8'); }
  const text = decoder.decode(await res.arrayBuffer());

  if (kind === 'html') {
    out.set('content-type', 'text/html; charset=utf-8');
    return new Response(self.SJ.rewriteHtml(text, target.href, { inject: inject(target) }), meta);
  }
  let js = self.SJ.rewriteJs(text);
  if (dest === 'worker' || dest === 'sharedworker') js = PRELUDE + js;
  if (/javascript|ecmascript/.test(type)) out.set('content-type', 'text/javascript; charset=utf-8');
  return new Response(js, meta);
}
XCLOUD_FILE_END
cat > "$APP/public/__sj/rewrite.js" <<'XCLOUD_FILE_END'
/*
 * Shared rewriting core. Loaded by the service worker (importScripts),
 * by proxied pages (<script>), and by the Node server (require).
 *
 * URL scheme: a target URL is proxied as  <proxy-origin>/p/<absolute target URL>
 * e.g. /p/https://example.com/a/b?c=1. Because the target URL is left
 * unencoded, relative URLs inside a page resolve to proxied URLs for free.
 */
(function (root) {
  'use strict';

  const PREFIX = '/p/';

  // ---------------------------------------------------------------- URLs

  // The proxy's own origin (undefined on the server).
  const PROXY_ORIGIN = root.location && root.location.origin;

  function encodeUrl(url, base) {
    const s = String(url);
    if (s.startsWith(PREFIX + 'http')) return s; // already proxied
    let u;
    try { u = new URL(s, base); } catch { return s; }
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return s; // data:, blob:, mailto:, ...
    if (PROXY_ORIGIN && u.origin === PROXY_ORIGIN) {
      // Built against the proxy's address (e.g. new URL('/x', import.meta.url)).
      const rest = u.pathname + u.search + u.hash;
      if (rest.startsWith(PREFIX)) return rest;
      try { u = new URL(rest, new URL(base).origin); } catch { return s; }
    }
    return PREFIX + u.href;
  }

  // Returns the target URL string for a proxied URL, or null if it isn't one.
  function decode(str, origin) {
    let s = String(str);
    if (origin && s.startsWith(origin + PREFIX)) s = s.slice(origin.length);
    if (s.startsWith(PREFIX)) {
      const rest = s.slice(PREFIX.length);
      if (/^https?:\/\//i.test(rest)) return rest;
    }
    return null;
  }

  const URL_ATTRS = new Set(['href', 'src', 'action', 'formaction', 'poster', 'background', 'manifest', 'xlink:href']);
  function isUrlAttr(tag, attr) {
    return URL_ATTRS.has(attr) || (attr === 'data' && tag === 'object');
  }

  function rewriteUrlAttr(value, base) {
    const v = String(value).trim();
    if (!v || v[0] === '#') return String(value);
    if (/^javascript:/i.test(v)) return 'javascript:' + rewriteJs(v.slice(11));
    return encodeUrl(v, base);
  }

  function rewriteSrcset(value, base) {
    const s = String(value);
    const out = [];
    let i = 0;
    while (i < s.length) {
      while (i < s.length && /[\s,]/.test(s[i])) i++;
      if (i >= s.length) break;
      let j = i;
      while (j < s.length && !/\s/.test(s[j])) j++;
      let url = s.slice(i, j);
      let desc = '';
      if (url.endsWith(',')) {
        url = url.replace(/,+$/, '');
      } else {
        let k = j;
        while (k < s.length && s[k] !== ',') k++;
        desc = s.slice(j, k).trim();
        j = k;
      }
      out.push(encodeUrl(url, base) + (desc ? ' ' + desc : ''));
      i = j;
    }
    return out.join(', ');
  }

  // ---------------------------------------------------------------- JS
  // A small tokenizer that skips strings, comments, template literals and
  // regex literals, and renames the identifiers below. Renaming is
  // consistent across a file, so local variables keep working; global and
  // member access goes through Object.prototype accessors (see install())
  // that answer for windows/documents and forward to the real property for
  // every other object (so `el.style.top`, `node.parent` still work).
  // Object-literal keys keep their names; shorthand `{top}` becomes
  // `{top: __sjTop}`, which is right for both literals and destructuring.

  const RENAME = { location: '__sjLocation', top: '__sjTop', parent: '__sjParent', frameElement: '__sjFrameElement' };
  const RENAME_WORDS = Object.keys(RENAME);
  const REGEX_AFTER_KW = new Set(['return', 'typeof', 'instanceof', 'in', 'of', 'new', 'delete', 'void',
    'throw', 'case', 'do', 'else', 'yield', 'await', 'extends']);
  const END_MODULE_CLAUSE = new Set(['class', 'function', 'const', 'let', 'var', 'default', 'async']);

  function idStart(c) { return (c >= 97 && c <= 122) || (c >= 65 && c <= 90) || c === 36 || c === 95 || c === 92 || c >= 128; }
  function idPart(c) { return idStart(c) || (c >= 48 && c <= 57); }
  function isWs(c) { return c === 32 || c === 9 || c === 10 || c === 13 || c === 11 || c === 12 || c === 0xa0 || c === 0xfeff || c === 0x2028 || c === 0x2029; }

  function rewriteJs(input) {
    const src = String(input);
    if (!RENAME_WORDS.some((w) => src.indexOf(w) !== -1)) return src;
    const n = src.length;
    const hits = []; // [pos, len, replacement]
    // Open brackets: 0 = brace, 1 = template substitution, 2 = import/export
    // clause braces, 3 = paren/bracket.
    const stack = [];
    let i = 0, last = '', lastType = '', moduleClause = false;

    function scanString(j, q) {
      j++;
      while (j < n) {
        const c = src.charCodeAt(j);
        if (c === 92) j += 2;
        else if (c === q) return j + 1;
        else if (c === 10) return j;
        else j++;
      }
      return n;
    }
    function scanTemplate(j) {
      while (j < n) {
        const c = src.charCodeAt(j);
        if (c === 92) j += 2;
        else if (c === 96) return { end: j + 1, done: true };
        else if (c === 36 && src.charCodeAt(j + 1) === 123) return { end: j + 2, done: false };
        else j++;
      }
      return { end: n, done: true };
    }
    function scanRegex(j) {
      let k = j + 1, inClass = false;
      while (k < n) {
        const ch = src[k];
        if (ch === '\\') { k += 2; continue; }
        if (ch === '\n') return -1;
        if (inClass) { if (ch === ']') inClass = false; }
        else if (ch === '[') inClass = true;
        else if (ch === '/') { k++; break; }
        k++;
      }
      while (k < n && idPart(src.charCodeAt(k))) k++;
      return k;
    }
    function regexOk() {
      if (lastType === '') return true;
      if (lastType === 'punc') return !(last === ')' || last === ']' || last === '}');
      if (lastType === 'id') return REGEX_AFTER_KW.has(last);
      return false;
    }
    function nextNonWs(j) {
      while (j < n && isWs(src.charCodeAt(j))) j++;
      return src[j];
    }

    while (i < n) {
      const c = src.charCodeAt(i);
      if (isWs(c)) { i++; continue; }
      if (c === 47) { // '/'
        const d = src.charCodeAt(i + 1);
        if (d === 47) { const e = src.indexOf('\n', i); i = e < 0 ? n : e; continue; }
        if (d === 42) { const e = src.indexOf('*/', i + 2); i = e < 0 ? n : e + 2; continue; }
        if (regexOk()) {
          const e = scanRegex(i);
          if (e > 0) { i = e; lastType = 'regex'; last = ''; continue; }
        }
        i++; lastType = 'punc'; last = '/'; continue;
      }
      if (c === 34 || c === 39) { i = scanString(i, c); lastType = 'str'; last = ''; continue; }
      if (c === 96) {
        const r = scanTemplate(i + 1);
        i = r.end; if (!r.done) stack.push(1);
        lastType = 'tmpl'; last = ''; continue;
      }
      if (idStart(c)) {
        let j = i + 1;
        while (j < n && idPart(src.charCodeAt(j))) j++;
        const word = src.slice(i, j);
        const afterDot = lastType === 'punc' && last === '.';
        if (!afterDot && (word === 'import' || word === 'export')) moduleClause = true;
        else if (END_MODULE_CLAUSE.has(word)) moduleClause = false;
        const rep = Object.prototype.hasOwnProperty.call(RENAME, word) ? RENAME[word] : null;
        if (rep) {
          const top = stack[stack.length - 1];
          const listStart = lastType === 'punc' && (last === '{' || last === ',');
          const next = listStart ? nextNonWs(j) : '';
          if (top === 2) hits.push([i, word.length, rep]);
          else if (listStart && next === ':') { /* object key: keep */ }
          else if (listStart && top === 0 && (next === '}' || next === ',')) hits.push([i, word.length, word + ': ' + rep]);
          else hits.push([i, word.length, rep]);
        }
        lastType = 'id'; last = word; i = j; continue;
      }
      if ((c >= 48 && c <= 57) || (c === 46 && src.charCodeAt(i + 1) >= 48 && src.charCodeAt(i + 1) <= 57)) {
        let j = i + 1;
        while (j < n) {
          const d = src.charCodeAt(j);
          if (idPart(d) || d === 46) j++;
          else if ((d === 43 || d === 45) && (src[j - 1] === 'e' || src[j - 1] === 'E') && !/^0[xX]/.test(src.slice(i, i + 2))) j++;
          else break;
        }
        lastType = 'num'; last = ''; i = j; continue;
      }
      if (c === 123) { stack.push(moduleClause ? 2 : 0); moduleClause = false; }
      else if (c === 40 || c === 91) { stack.push(3); moduleClause = false; }
      else if (c === 41 || c === 93) stack.pop();
      else if (c === 59 || c === 61) moduleClause = false;
      else if (c === 125) {
        if (stack.pop() === 1) {
          const r = scanTemplate(i + 1);
          i = r.end; if (!r.done) stack.push(1);
          lastType = 'tmpl'; last = ''; continue;
        }
      }
      last = src[i]; lastType = 'punc'; i++;
    }

    if (!hits.length) return src;
    let out = '', prev = 0;
    for (const [pos, len, rep] of hits) { out += src.slice(prev, pos) + rep; prev = pos + len; }
    return out + src.slice(prev);
  }

  // ---------------------------------------------------------------- HTML
  // A forgiving tag scanner (no DOM needed, so it runs in the service worker).

  const RAW_TEXT = new Set(['script', 'style', 'textarea', 'title', 'xmp', 'iframe', 'noembed', 'noframes', 'noscript', 'plaintext']);
  const TAG_RE = /<([a-zA-Z][^\s\/>]*)((?:[^>"']|"[^"]*"|'[^']*')*)>/y;
  const ATTR_RE = /([^\s"'>\/=]+)(\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g;

  function decodeEntities(s) {
    return s.replace(/&(#x[0-9a-f]+|#\d+|amp|quot|apos|lt|gt|nbsp);?/gi, (m, e) => {
      const l = e.toLowerCase();
      if (l[0] === '#') {
        const cp = l[1] === 'x' ? parseInt(l.slice(2), 16) : parseInt(l.slice(1), 10);
        try { return String.fromCodePoint(cp); } catch { return m; }
      }
      return { amp: '&', quot: '"', apos: "'", lt: '<', gt: '>', nbsp: ' ' }[l];
    });
  }
  function escapeAttr(s) { return s.replace(/&/g, '&amp;').replace(/"/g, '&quot;'); }

  function isJsType(t) {
    if (t == null) return true;
    t = t.trim().toLowerCase();
    if (t === '' || t === 'module') return true;
    return /(java|ecma|j|live)script/.test(t) && !t.includes('json');
  }

  function rewriteTag(tag, rawName, attrText, ctx) {
    const attrs = [];
    let m;
    ATTR_RE.lastIndex = 0;
    while ((m = ATTR_RE.exec(attrText))) {
      const hasValue = m[2] != null;
      const raw = hasValue ? (m[3] ?? m[4] ?? m[5] ?? '') : null;
      attrs.push({ name: m[1], lname: m[1].toLowerCase(), raw, text: m[0] });
    }
    const get = (n) => { const a = attrs.find((x) => x.lname === n); return a && a.raw != null ? decodeEntities(a.raw) : null; };

    if (tag === 'meta') {
      const equiv = (get('http-equiv') || '').toLowerCase();
      if (equiv === 'content-security-policy' || equiv === 'content-security-policy-report-only') {
        return { text: '<' + rawName + ' data-sj-disabled-csp="">', js: false };
      }
    }
    if (tag === 'base') {
      const href = get('href');
      if (href != null) { try { ctx.base = new URL(href, ctx.base).href; } catch { /* ignore */ } }
    }

    let changed = false;
    const parts = [];
    for (const a of attrs) {
      let nv = null;
      if (a.lname === 'integrity') { changed = true; continue; }
      if (a.raw != null) {
        const val = decodeEntities(a.raw);
        if (isUrlAttr(tag, a.lname)) nv = rewriteUrlAttr(val, ctx.base);
        else if (a.lname === 'srcset' || a.lname === 'imagesrcset') nv = rewriteSrcset(val, ctx.base);
        else if (a.lname.startsWith('on')) nv = rewriteJs(val);
        else if (tag === 'meta' && a.lname === 'content' && (get('http-equiv') || '').toLowerCase() === 'refresh') {
          const mm = /^(\s*\d*\.?\d*\s*[;,]?\s*(?:url\s*=\s*)?)(['"]?)(.*?)\2\s*$/i.exec(val);
          if (mm && mm[3]) nv = mm[1] + encodeUrl(mm[3], ctx.base);
        }
        if (nv != null && nv !== val) { changed = true; parts.push(' ' + a.name + '="' + escapeAttr(nv) + '"'); continue; }
      }
      parts.push(' ' + a.text);
    }

    const js = tag === 'script' && isJsType(get('type'));
    const module = js && (get('type') || '').trim().toLowerCase() === 'module';
    if (!changed) return { text: '<' + rawName + attrText + '>', js, module };
    const selfClose = /\/\s*$/.test(attrText) ? ' /' : '';
    return { text: '<' + rawName + parts.join('') + selfClose + '>', js, module };
  }

  // opts.inject: markup inserted at the top of <head> (omit for fragments).
  function rewriteHtml(input, base, opts) {
    const html = String(input);
    const ctx = { base };
    const inject = (opts && opts.inject) || '';
    let injected = !inject;
    const out = [];
    const n = html.length;
    let i = 0;

    const copyTo = (str, from) => { const e = html.indexOf(str, from); const end = e === -1 ? n : e + str.length; out.push(html.slice(i, end)); i = end; };

    while (i < n) {
      const lt = html.indexOf('<', i);
      if (lt === -1) { out.push(html.slice(i)); break; }
      out.push(html.slice(i, lt));
      i = lt;
      if (html.startsWith('<!--', i)) { copyTo('-->', i + 4); continue; }
      const next = html[i + 1];
      if (next === '!' || next === '?' || next === '/') { copyTo('>', i); continue; }
      TAG_RE.lastIndex = i;
      const m = TAG_RE.exec(html);
      if (!m) { out.push('<'); i++; continue; }
      const tag = m[1].toLowerCase();
      if (!injected && tag !== 'html' && tag !== 'head') { out.push(inject); injected = true; }
      const res = rewriteTag(tag, m[1], m[2], ctx);
      out.push(res.text);
      i = TAG_RE.lastIndex;
      if (!injected && tag === 'head') { out.push(inject); injected = true; }
      if (RAW_TEXT.has(tag) && !/\/\s*$/.test(m[2])) {
        const close = new RegExp('</' + tag + '(?=[\\s/>])', 'ig');
        close.lastIndex = i;
        const cm = close.exec(html);
        const end = cm ? cm.index : n;
        let body = html.slice(i, end);
        if (tag === 'script' && res.js) {
          const rewritten = rewriteJs(body);
          // React (and others) compare inline script text when hydrating, so
          // the rewritten code first puts the original text back on its
          // element. Module scripts have no currentScript; those keep the
          // rewritten text.
          if (rewritten !== body) {
            body = res.module ? rewritten
              : '__sjRestore(document.currentScript,' + JSON.stringify(body).replace(/</g, '\\u003c') + ');' + rewritten;
          }
        }
        out.push(body);
        i = end;
      }
    }
    if (!injected) out.unshift(inject);
    return out.join('');
  }

  // ---------------------------------------------------------------- cookies
  // Every target cookie is stored on the proxy origin under a name that
  // records its scope:  <name>~h~<host>  (host-only) or  <name>~d~<domain>.

  function cookieKey(name, flag, domain) {
    if (/^__(host|secure)-/i.test(name)) name = '~' + name; // dodge browser prefix rules
    return name + '~' + flag + '~' + domain;
  }
  function parseKey(key) {
    const m = /^(.*)~([hd])~([^~]*)$/.exec(key);
    if (!m) return null;
    let name = m[1];
    if (name.startsWith('~__')) name = name.slice(1);
    return { name, flag: m[2], domain: m[3] };
  }
  function domainMatch(host, k) {
    host = host.toLowerCase();
    return k.flag === 'h' ? host === k.domain : host === k.domain || host.endsWith('.' + k.domain);
  }
  // Proxy-origin Cookie header -> Cookie header for `host`.
  function filterCookies(header, host) {
    const out = [];
    for (const part of String(header || '').split(/;\s*/)) {
      if (!part) continue;
      const eq = part.indexOf('=');
      const key = (eq < 0 ? part : part.slice(0, eq)).trim();
      const k = parseKey(key);
      if (k && domainMatch(host, k)) out.push(k.name + '=' + (eq < 0 ? '' : part.slice(eq + 1)));
    }
    return out.join('; ');
  }
  // Target Set-Cookie -> Set-Cookie for the proxy origin (null = reject).
  function rewriteSetCookie(str, host, secure) {
    const parts = String(str).split(';');
    const first = parts.shift();
    const eq = first.indexOf('=');
    if (eq < 0) return null;
    const name = first.slice(0, eq).trim();
    const value = first.slice(eq + 1);
    if (!name) return null;
    host = host.toLowerCase();
    let domain = null, hadSecure = false;
    const attrs = [];
    for (const p of parts) {
      const t = p.trim();
      const k = t.indexOf('=');
      const an = (k < 0 ? t : t.slice(0, k)).toLowerCase();
      const av = k < 0 ? '' : t.slice(k + 1).trim();
      if (an === 'domain') { if (av) domain = av.replace(/^\./, '').toLowerCase(); }
      else if (an === 'secure') hadSecure = true;
      else if (an === 'expires' || an === 'max-age' || an === 'httponly') attrs.push(t);
    }
    if (domain && !(host === domain || host.endsWith('.' + domain))) return null;
    const key = domain ? cookieKey(name, 'd', domain) : cookieKey(name, 'h', host);
    attrs.push('Path=/', 'SameSite=Lax');
    if (secure && hadSecure) attrs.push('Secure');
    return key + '=' + value + '; ' + attrs.join('; ');
  }

  // ---------------------------------------------------------------- runtime
  // Installs the fake Location for a realm (window or worker). This function
  // is also stringified and prepended to worker scripts, so it must not
  // reference anything outside itself.

  function install(G) {
    if (Object.prototype.hasOwnProperty.call(Object.prototype, '__sjLocation')) return;
    const real = G.location;
    const ORIGIN = real.origin;
    const P = '/p/';
    const cur = () => new URL(real.href.slice(ORIGIN.length + P.length));
    const go = (u, replace) => {
      const abs = new URL(String(u), cur());
      if (abs.protocol === 'javascript:') return;
      const dest = /^https?:$/.test(abs.protocol) ? P + abs.href : abs.href;
      replace ? real.replace(dest) : real.assign(dest);
    };
    const fake = {};
    for (const p of ['href', 'origin', 'protocol', 'host', 'hostname', 'port', 'pathname', 'search', 'hash']) {
      Object.defineProperty(fake, p, {
        enumerable: true,
        get() { return cur()[p]; },
        set: p === 'origin' ? undefined : function (v) {
          if (p === 'href') return go(v);
          if (p === 'hash') { real.hash = v; return; }
          const u = cur(); u[p] = v; go(u.href);
        },
      });
    }
    fake.assign = (u) => go(u);
    fake.replace = (u) => go(u, true);
    fake.reload = () => real.reload();
    fake.toString = () => cur().href;
    fake.valueOf = () => fake;
    fake[Symbol.toPrimitive] = () => cur().href;
    Object.defineProperty(G, '__sj$loc', { value: fake });

    const doc = G.document;
    const NodeC = G.Node;
    // Window, document, and DOM nodes (inline handlers resolve bare names
    // through the element's scope) all answer for this realm.
    const mine = (o) => o === G || (doc && o === doc) || (NodeC && o instanceof NodeC);
    const isWin = (o) => { try { return o != null && o.window === o; } catch { return false; } };
    const winOf = (o) => (isWin(o) ? o : mine(o) ? G : null);
    // The browser UI (shell) and anything cross-origin is outside the page's world.
    const outside = (w) => { try { return !!w.__sjShell || !w.location.href; } catch { return true; } };
    const vParent = (w) => { const p = w.parent; return p === w || outside(p) ? w : p; };
    const vTop = (w) => { let c = w; for (let k = 0; k < 64; k++) { const p = vParent(c); if (p === c) break; c = p; } return c; };

    const define = (name, get, set) => Object.defineProperty(Object.prototype, name, { configurable: true, enumerable: false, get, set });
    define('__sjLocation',
      function () { return mine(this) ? fake : (this == null ? undefined : this.location); },
      function (v) { if (mine(this)) go(v); else this.location = v; });
    // Other windows are wrapped (client.js) so the same-origin policy holds.
    const wrap = (w) => (w !== G && typeof G.__sjWrapWin === 'function' ? G.__sjWrapWin(w) : w);
    define('__sjTop',
      function () { const w = winOf(this); return w ? wrap(vTop(w)) : (this == null ? undefined : this.top); },
      function (v) { if (!winOf(this)) this.top = v; });
    define('__sjParent',
      function () { const w = winOf(this); return w ? wrap(vParent(w)) : (this == null ? undefined : this.parent); },
      function (v) { if (!winOf(this)) this.parent = v; });
    define('__sjFrameElement',
      function () { const w = winOf(this); if (!w) return this == null ? undefined : this.frameElement; return vParent(w) === w ? null : w.frameElement; },
      function (v) { if (!winOf(this)) this.frameElement = v; });
  }

  const SJ = {
    PREFIX, encodeUrl, decode, isUrlAttr, rewriteUrlAttr, rewriteSrcset,
    rewriteJs, rewriteHtml, filterCookies, rewriteSetCookie, install,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = SJ;
  else root.SJ = SJ;
})(typeof self !== 'undefined' ? self : globalThis);
XCLOUD_FILE_END
cat > "$APP/public/__sj/client.js" <<'XCLOUD_FILE_END'
/* Injected at the top of every proxied document. Makes the page believe it
 * lives at its target URL and routes anything URL-shaped back through /p/. */
(function () {
  'use strict';
  if (window.__sjClient) return;
  Object.defineProperty(window, '__sjClient', { value: true });

  const SJ = self.SJ;
  // Take the two injected <script> tags back out once they've run, so the
  // document's structure matches the server's HTML exactly (React compares).
  // (An import map stays in effect after its element is removed.)
  for (const el of document.querySelectorAll('script[data-sj]')) el.remove();
  const ORIGIN = location.origin;
  const realLoc = location;
  SJ.install(window);

  const desc = (o, p) => {
    for (let x = o; x; x = Object.getPrototypeOf(x)) {
      const d = Object.getOwnPropertyDescriptor(x, p);
      if (d) return d;
    }
    return null;
  };
  const baseGet = desc(Node.prototype, 'baseURI').get;
  const hrefDesc = desc(HTMLAnchorElement.prototype, 'href'); // unhooked
  const rawTextSet = desc(Node.prototype, 'textContent').set;
  // Called first by rewritten inline scripts: restore the original source
  // text on the element so frameworks that compare it (React hydration) match.
  Object.defineProperty(window, '__sjRestore', {
    value: (el, text) => { if (el) rawTextSet.call(el, text); },
  });

  const target = () => new URL(SJ.decode(realLoc.href, ORIGIN));
  const targetBase = () => SJ.decode(baseGet.call(document), ORIGIN) || target().href;
  const enc = (u) => SJ.encodeUrl(String(u), targetBase());
  const dec = (u) => (u == null ? u : SJ.decode(u, ORIGIN) ?? u);

  // Redefine an accessor on `proto` (looking it up the prototype chain).
  function hook(proto, prop, { get, set }) {
    const d = desc(proto, prop);
    if (!d || !d.get) return;
    Object.defineProperty(proto, prop, {
      configurable: true,
      enumerable: d.enumerable,
      get: get ? function () { return get.call(this, d.get); } : d.get,
      set: set && d.set ? function (v) { set.call(this, v, d.set); } : d.set,
    });
  }

  // ---- passkeys
  // A passkey is tied to the real site's domain (login.live.com), but every
  // proxied page really runs on this proxy's address, so the browser always
  // refuses it. Microsoft's sign-in tries passkeys first (passkey autofill,
  // "sign in with a passkey"), above all for Outlook/Hotmail accounts, many of
  // which are passwordless, and the sign-in then gets stuck. Look like a
  // browser without passkey support, so it offers the password, an emailed
  // code or the Authenticator app instead.
  try { Object.defineProperty(window, 'PublicKeyCredential', { configurable: true, writable: true, value: undefined }); } catch { /* ignore */ }
  if (window.CredentialsContainer) {
    const CC = CredentialsContainer.prototype;
    for (const m of ['get', 'create']) {
      const orig = CC[m];
      if (typeof orig !== 'function') continue;
      CC[m] = function (opts) {
        if (opts && opts.publicKey) return Promise.reject(new DOMException('Passkeys are not available through the proxy.', 'NotAllowedError'));
        return orig.apply(this, arguments);
      };
    }
  }

  // ---- per-site storage
  // Every proxied page really shares the proxy's one origin, so without
  // this, all sites would share one localStorage/IndexedDB. Sites then
  // overwrite or delete each other's data. Xbox in particular: www.xbox.com
  // (loaded in a hidden frame) computes the same storage key as
  // play.xbox.com and deletes its saved sign-in tokens. Give each site
  // its own namespace, as a real browser does.
  const SITE = target().origin + '|';
  function partitionStorage(name) {
    let real;
    try { real = window[name]; } catch { return; }
    if (!real) return;
    const keys = () => {
      const out = [];
      for (let i = 0; i < real.length; i++) { const k = real.key(i); if (k && k.startsWith(SITE)) out.push(k.slice(SITE.length)); }
      return out;
    };
    // (configurable, so the Proxy may hide them from Object.keys)
    const api = Object.create(Storage.prototype, {
      getItem: { value: (k) => real.getItem(SITE + k), configurable: true },
      setItem: { value: (k, v) => real.setItem(SITE + k, String(v)), configurable: true },
      removeItem: { value: (k) => real.removeItem(SITE + k), configurable: true },
      clear: { value: () => { for (const k of keys()) real.removeItem(SITE + k); }, configurable: true },
      key: { value: (i) => { const k = keys()[i]; return k === undefined ? null : k; }, configurable: true },
      length: { get: () => keys().length, configurable: true },
    });
    const own = (k) => typeof k === 'symbol' || k in api;
    const proxy = new Proxy(api, {
      get(t, k) { if (own(k)) return Reflect.get(t, k); const v = real.getItem(SITE + k); return v === null ? undefined : v; },
      set(t, k, v) { if (own(k)) return false; real.setItem(SITE + k, String(v)); return true; },
      has(t, k) { return own(k) || real.getItem(SITE + k) !== null; },
      deleteProperty(t, k) { if (!own(k)) real.removeItem(SITE + k); return true; },
      ownKeys() { return keys(); },
      getOwnPropertyDescriptor(t, k) {
        if (own(k)) return undefined;
        const v = real.getItem(SITE + k);
        return v === null ? undefined : { value: v, writable: true, enumerable: true, configurable: true };
      },
    });
    try { Object.defineProperty(window, name, { configurable: true, enumerable: true, get: () => proxy }); } catch { /* leave shared */ }
  }
  partitionStorage('localStorage');
  partitionStorage('sessionStorage');
  hook(StorageEvent.prototype, 'key', {
    get(o) { const k = o.call(this); return typeof k === 'string' && k.startsWith(SITE) ? k.slice(SITE.length) : k; },
  });
  if (window.IDBFactory) {
    const F = IDBFactory.prototype;
    const idbOpen = F.open, idbDelete = F.deleteDatabase, idbList = F.databases;
    F.open = function (n, ...rest) { return idbOpen.call(this, SITE + n, ...rest); };
    F.deleteDatabase = function (n) { return idbDelete.call(this, SITE + n); };
    if (idbList) {
      F.databases = function () {
        return idbList.call(this).then((l) => l.filter((d) => d.name.startsWith(SITE)).map((d) => ({ ...d, name: d.name.slice(SITE.length) })));
      };
    }
    hook(IDBDatabase.prototype, 'name', {
      get(o) { const n = o.call(this); return n.startsWith(SITE) ? n.slice(SITE.length) : n; },
    });
  }
  if (window.CacheStorage) {
    const C = CacheStorage.prototype;
    for (const m of ['open', 'has', 'delete']) {
      const orig = C[m];
      C[m] = function (n, ...rest) { return orig.call(this, SITE + n, ...rest); };
    }
    const cKeys = C.keys;
    C.keys = function () { return cKeys.call(this).then((l) => l.filter((n) => n.startsWith(SITE)).map((n) => n.slice(SITE.length))); };
  }
  if (window.BroadcastChannel) {
    const RealBC = BroadcastChannel;
    window.BroadcastChannel = new Proxy(RealBC, { construct(t, args, nt) { args[0] = SITE + args[0]; return Reflect.construct(t, args, nt); } });
    hook(RealBC.prototype, 'name', { get(o) { const n = o.call(this); return n.startsWith(SITE) ? n.slice(SITE.length) : n; } });
  }

  // ---- same-origin policy between proxied frames/windows
  // Every proxied page really shares the proxy's origin, so one frame could
  // read another's address even when they show different sites. Sign-in
  // libraries (MSAL) rely on that read *throwing* until their hidden frame
  // is back on their own site, so other windows are handed out wrapped:
  // while the window shows a different site, reading its location or
  // document throws SecurityError like a real browser. Navigating it and
  // postMessage keep working.
  const rawSourceGet = desc(MessageEvent.prototype, 'source').get;
  // Every proxied page's real origin is the proxy's, so a targetOrigin naming
  // the site would never match: send to '*' instead.
  const nativePM = window.postMessage;
  Object.defineProperty(window, '__sj$pm', { value: nativePM });
  function fixTargetOrigin(o) {
    if (o && typeof o === 'object') return Object.assign({}, o, { targetOrigin: '*' });
    return typeof o === 'string' && o !== '/' ? '*' : o;
  }
  function winOrigin(w) {
    try {
      const h = w.location.href; // real location (this file isn't rewritten)
      const t = SJ.decode(h, ORIGIN);
      if (t) return new URL(t).origin;
      if (h === '' || h.startsWith('about:')) return null; // inherits its creator's origin
      return 'x-other:' + new URL(h).origin;
    } catch { return 'x-unreachable'; }
  }
  const isCross = (w) => { const o = winOrigin(w); return o !== null && o !== target().origin; };
  const secErr = () => new DOMException('Blocked a frame from accessing a cross-origin frame.', 'SecurityError');
  function crossLocation(w) {
    const nav = (u, replace) => {
      const dest = SJ.rewriteUrlAttr(String(u), targetBase());
      replace ? w.location.replace(dest) : (w.location.href = dest);
    };
    const o = {};
    for (const k of ['hash', 'host', 'hostname', 'origin', 'pathname', 'port', 'protocol', 'search', 'ancestorOrigins']) {
      Object.defineProperty(o, k, { get() { throw secErr(); } });
    }
    Object.defineProperty(o, 'href', { get() { throw secErr(); }, set(v) { nav(v); } });
    o.replace = (u) => nav(u, true);
    o.assign = (u) => nav(u);
    o.reload = () => { throw secErr(); };
    o.toString = () => { throw secErr(); };
    return o;
  }
  const wrappedWins = new WeakMap();
  const winProxies = new WeakSet();
  function wrapWin(w) {
    if (!w || w === window || winProxies.has(w)) return w;
    try { if (w.window !== w) return w; } catch { return w; }
    let p = wrappedWins.get(w);
    if (p) return p;
    const bound = new Map();
    p = new Proxy(w, {
      get(t, k) {
        if (k === '__sjLocation' || k === 'location') {
          if (isCross(t)) return crossLocation(t);
          const l = Reflect.get(t, '__sjLocation');
          return l === undefined ? t.location : l;
        }
        if (k === 'document' && isCross(t)) throw secErr();
        if (k === 'postMessage') {
          // Called through this realm's function, so the receiver's
          // event.source is this window (the target's own patched
          // postMessage would make it the target itself).
          let b = bound.get(k);
          if (!b) {
            b = { b: function (msg, targetOrigin, transfer) {
              const native = t.__sj$pm || Reflect.get(t, 'postMessage');
              return native.call(t, msg, fixTargetOrigin(targetOrigin), transfer);
            } };
            bound.set(k, b);
          }
          return b.b;
        }
        const v = Reflect.get(t, k);
        if (typeof v === 'function' && typeof k === 'string' && !/^[A-Z]/.test(k)) {
          let b = bound.get(k);
          if (!b || b.f !== v) { b = { f: v, b: v.bind(t) }; bound.set(k, b); }
          return b.b; // window methods (postMessage, close, ...) need the real window as `this`
        }
        return v;
      },
      set(t, k, v) {
        if (k === '__sjLocation' || k === 'location') {
          if (isCross(t)) crossLocation(t).href = v;
          else if (!Reflect.set(t, '__sjLocation', v)) t.location.href = SJ.rewriteUrlAttr(String(v), targetBase());
          return true;
        }
        if (isCross(t)) throw secErr();
        return Reflect.set(t, k, v);
      },
    });
    winProxies.add(p);
    wrappedWins.set(w, p);
    return p;
  }
  // top / parent (see install() in rewrite.js) also hand out wrapped windows.
  Object.defineProperty(window, '__sjWrapWin', { value: wrapWin });
  for (const C of ['HTMLIFrameElement', 'HTMLFrameElement', 'HTMLObjectElement']) {
    if (!window[C]) continue;
    hook(window[C].prototype, 'contentWindow', { get(o) { return wrapWin(o.call(this)); } });
    hook(window[C].prototype, 'contentDocument', {
      get(o) { const d = o.call(this); return d && d.defaultView && isCross(d.defaultView) ? null : d; },
    });
  }
  hook(MessageEvent.prototype, 'source', {
    get(o) { const s = o.call(this); try { return s && s.window === s ? wrapWin(s) : s; } catch { return s; } },
  });
  try { hook(window, 'opener', { get(o) { return wrapWin(o.call(this)); } }); } catch { /* not redefinable here */ }

  // ---- URL-bearing element properties
  const URL_PROPS = [
    ['HTMLAnchorElement', 'href'], ['HTMLAreaElement', 'href'], ['HTMLLinkElement', 'href'],
    ['HTMLBaseElement', 'href'], ['HTMLFormElement', 'action'], ['HTMLButtonElement', 'formAction'],
    ['HTMLInputElement', 'formAction'], ['HTMLIFrameElement', 'src'], ['HTMLFrameElement', 'src'],
    ['HTMLScriptElement', 'src'], ['HTMLImageElement', 'src'], ['HTMLSourceElement', 'src'],
    ['HTMLMediaElement', 'src'], ['HTMLEmbedElement', 'src'], ['HTMLTrackElement', 'src'],
    ['HTMLInputElement', 'src'], ['HTMLObjectElement', 'data'], ['HTMLVideoElement', 'poster'],
  ];
  for (const [ctor, prop] of URL_PROPS) {
    if (!window[ctor]) continue;
    hook(window[ctor].prototype, prop, {
      get(o) { return dec(o.call(this)); },
      set(v, o) { o.call(this, SJ.rewriteUrlAttr(v, targetBase())); },
    });
  }
  for (const ctor of ['HTMLImageElement', 'HTMLSourceElement']) {
    hook(window[ctor].prototype, 'srcset', { set(v, o) { o.call(this, SJ.rewriteSrcset(v, targetBase())); } });
  }
  // a.host, a.pathname, ... should describe the target URL too.
  for (const ctor of ['HTMLAnchorElement', 'HTMLAreaElement']) {
    for (const p of ['origin', 'protocol', 'host', 'hostname', 'port', 'pathname']) {
      hook(window[ctor].prototype, p, {
        get(o) { try { return new URL(this.href)[p]; } catch { return o.call(this); } },
      });
    }
  }

  // ---- attributes
  const E = Element.prototype;
  const setAttr = E.setAttribute, getAttr = E.getAttribute;
  E.setAttribute = function (name, value) {
    const n = String(name).toLowerCase();
    let v = String(value);
    const tag = this.tagName.toLowerCase();
    if (n === 'integrity') return;
    if (SJ.isUrlAttr(tag, n)) v = SJ.rewriteUrlAttr(v, targetBase());
    else if (n === 'srcset' || n === 'imagesrcset') v = SJ.rewriteSrcset(v, targetBase());
    else if (n.startsWith('on')) v = SJ.rewriteJs(v);
    return setAttr.call(this, name, v);
  };
  E.getAttribute = function (name) {
    const v = getAttr.call(this, name);
    return v != null && SJ.isUrlAttr(this.tagName.toLowerCase(), String(name).toLowerCase()) ? dec(v) : v;
  };

  // ---- HTML and script text injection
  const isScript = (el) => el instanceof HTMLScriptElement;
  hook(E, 'innerHTML', {
    set(v, o) {
      if (isScript(this)) o.call(this, SJ.rewriteJs(v));
      else if (this instanceof HTMLStyleElement) o.call(this, v);
      else o.call(this, SJ.rewriteHtml(String(v), targetBase()));
    },
  });
  hook(E, 'outerHTML', { set(v, o) { o.call(this, SJ.rewriteHtml(String(v), targetBase())); } });
  const iah = E.insertAdjacentHTML;
  E.insertAdjacentHTML = function (pos, html) { return iah.call(this, pos, SJ.rewriteHtml(String(html), targetBase())); };
  for (const m of ['write', 'writeln']) {
    const orig = Document.prototype[m];
    Document.prototype[m] = function (...a) { return orig.call(this, SJ.rewriteHtml(a.join(''), targetBase())); };
  }
  for (const p of ['text', 'textContent', 'innerText']) {
    const d = desc(HTMLScriptElement.prototype, p);
    if (!d) continue;
    Object.defineProperty(HTMLScriptElement.prototype, p, {
      configurable: true,
      get() { return d.get.call(this); },
      set(v) { d.set.call(this, SJ.rewriteJs(String(v))); },
    });
  }
  const append = Node.prototype.appendChild;
  Node.prototype.appendChild = function (child) {
    if (isScript(this) && child && child.nodeType === 3) child.data = SJ.rewriteJs(child.data);
    return append.call(this, child);
  };

  // ---- strings evaluated as code (direct eval is left alone: wrapping it breaks scoping)
  for (const t of ['setTimeout', 'setInterval']) {
    const orig = window[t];
    window[t] = function (fn, ...rest) { return orig.call(this, typeof fn === 'string' ? SJ.rewriteJs(fn) : fn, ...rest); };
  }
  const RealFunction = Function;
  const ProxyFunction = function (...args) {
    if (args.length) args[args.length - 1] = SJ.rewriteJs(String(args[args.length - 1]));
    return RealFunction.apply(this, args);
  };
  ProxyFunction.prototype = RealFunction.prototype;
  Object.defineProperty(RealFunction.prototype, 'constructor', { value: ProxyFunction, configurable: true, writable: true });
  window.Function = ProxyFunction;

  // ---- network
  const realFetch = window.fetch;
  window.fetch = function (input, init) {
    if (typeof input === 'string' || input instanceof URL) input = enc(input);
    return realFetch.call(this, input, init);
  };
  hook(Response.prototype, 'url', { get(o) { return dec(o.call(this)); } });
  const xhrOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) { return xhrOpen.call(this, method, enc(url), ...rest); };
  hook(XMLHttpRequest.prototype, 'responseURL', { get(o) { return dec(o.call(this)); } });
  if (navigator.sendBeacon) {
    const beacon = navigator.sendBeacon;
    navigator.sendBeacon = function (url, data) { return beacon.call(navigator, enc(url), data); };
  }
  const wrapCtor = (name, fix) => {
    if (!window[name]) return;
    window[name] = new Proxy(window[name], { construct(t, args, nt) { fix(args); return Reflect.construct(t, args, nt); } });
  };
  wrapCtor('EventSource', (a) => { a[0] = enc(a[0]); });
  wrapCtor('Worker', (a) => { a[0] = enc(a[0]); });
  wrapCtor('SharedWorker', (a) => { a[0] = enc(a[0]); });
  wrapCtor('WebSocket', (a) => {
    const u = new URL(String(a[0]), targetBase());
    if (u.protocol === 'https:') u.protocol = 'wss:';
    else if (u.protocol === 'http:') u.protocol = 'ws:';
    a[0] = (realLoc.protocol === 'https:' ? 'wss://' : 'ws://') + realLoc.host +
      '/__sj/ws?url=' + encodeURIComponent(u.href) + '&origin=' + encodeURIComponent(target().origin);
  });
  hook(WebSocket.prototype, 'url', {
    get(o) {
      const v = o.call(this);
      try { return new URL(v).searchParams.get('url') || v; } catch { return v; }
    },
  });

  // ---- navigation
  // The tabbed UI, if this page is running inside it.
  let shell = null, inShellTab = false;
  try {
    for (let w = window; w.parent !== w; w = w.parent) {
      if (w.parent.__sjShell) { shell = w.parent.__sjShell; inShellTab = w === window; break; }
    }
  } catch { /* not ours */ }
  const absTarget = (u) => new URL(String(u), targetBase()).href;
  if (shell && shell.report) {
    const where = () => { try { return target().href; } catch { return ''; } };
    window.addEventListener('error', (e) => {
      if (e.message) shell.report({ kind: 'error', url: where(), detail: e.message + (e.filename ? ' @ ' + (dec(e.filename) || e.filename) + ':' + e.lineno : '') });
    });
    // Xbox's sign-in errors carry the real reason in `cause`, which its
    // telemetry drops. Its error classes call Error.captureStackTrace, so
    // look at auth-related errors as they are created and report the chain.
    if (typeof Error.captureStackTrace === 'function') {
      const cst = Error.captureStackTrace;
      const seen = new Set();
      const AUTH = /xbox ?token|xbox user token|sisu|xsts|relying ?party|msa|sign.?in|create user|hydrat|proof ?key|signature|nsal/i;
      const chain = (e) => {
        const parts = [];
        for (let c = e, i = 0; c && i < 6; c = c.cause, i++) {
          if (typeof c !== 'object') { parts.push(String(c)); break; }
          let p = `${c.name || c.constructor && c.constructor.name || 'Error'}: ${c.message || ''}`;
          for (const k of ['type', 'errorCode', 'subError', 'status', 'statusCode', 'xErrorCode', 'authFailureStage', 'url']) {
            if (c[k] != null && typeof c[k] !== 'object') p += ` [${k}=${String(c[k]).slice(0, 120)}]`;
          }
          parts.push(p);
        }
        return parts.join(' <- caused by ');
      };
      Error.captureStackTrace = function (err, ...rest) {
        const r = cst.call(this, err, ...rest);
        try {
          if (err && AUTH.test(String(err.message || '') + ' ' + String(err.type || '')) && err.cause) {
            // the cause is attached by the time the constructor returns
            queueMicrotask(() => {
              try {
                const text = chain(err);
                if (!seen.has(text) && seen.size < 40) { seen.add(text); shell.report({ kind: 'error', url: where(), detail: '[auth error] ' + text }); }
              } catch { /* ignore */ }
            });
          }
        } catch { /* never break error creation */ }
        return r;
      };
    }
    // React logs errors caught by error boundaries with console.error.
    const cerr = console.error;
    let sent = 0;
    const fmt = (a) => {
      if (a instanceof Error) {
        const frames = String(a.stack || '').split('\n').slice(1, 4)
          .map((l) => l.trim().replace(/https?:\/\/[^\s)]*\/p\/(https?:\/\/)/g, '$1')).join(' < ');
        return `${a.name}: ${a.message}${frames ? ' | ' + frames : ''}`;
      }
      if (typeof a === 'string') return a;
      try { return JSON.stringify(a).slice(0, 200); } catch { return String(a); }
    };
    console.error = function (...args) {
      try {
        if (sent < 60) {
          const text = args.map(fmt).join(' ').replace(/\s+/g, ' ').slice(0, 600);
          if (!/Failed to load resource/.test(text)) { sent++; shell.report({ kind: 'error', url: where(), detail: '[console] ' + text }); }
        }
      } catch { /* never break logging */ }
      return cerr.apply(this, args);
    };
    window.addEventListener('unhandledrejection', (e) => {
      const r = e.reason;
      shell.report({ kind: 'error', url: where(), detail: 'Unhandled: ' + (r && (r.stack || r.message) || String(r)).split('\n').slice(0, 3).join(' ') });
    });
  }

  const open = window.open;
  window.open = function (url, name, features) {
    // Plain new-window calls become tabs; real popups (with features) stay popups.
    if (shell && url && !features && (!name || name === '_blank')) {
      try { return wrapWin(shell.openTab(absTarget(url))); } catch { /* fall through */ }
    }
    return wrapWin(open.call(this, url ? SJ.rewriteUrlAttr(url, targetBase()) : url, name, features));
  };
  for (const m of ['pushState', 'replaceState']) {
    const orig = History.prototype[m];
    History.prototype[m] = function (state, title, url) {
      return url == null ? orig.call(this, state, title) : orig.call(this, state, title, enc(url));
    };
  }
  // Last line of defense for links/forms whose URLs escaped rewriting.
  const fixReal = (real) => {
    if (!/^https?:/i.test(real) || real.startsWith(ORIGIN + SJ.PREFIX)) return null;
    const u = new URL(real);
    return SJ.PREFIX + (u.origin === ORIGIN ? new URL(u.pathname + u.search + u.hash, target().origin).href : real);
  };
  const effectiveTarget = (el) => {
    const t = getAttr.call(el, 'target');
    if (t != null) return t.toLowerCase();
    const b = document.querySelector('base[target]');
    return b ? getAttr.call(b, 'target').toLowerCase() : '';
  };
  // In a UI tab, _top/_parent would replace the whole browser UI.
  const retarget = (el) => {
    const t = effectiveTarget(el);
    if (inShellTab && (t === '_top' || t === '_parent')) setAttr.call(el, 'target', '_self');
  };
  const onClick = (e) => {
    const a = e.target && e.target.closest && e.target.closest('a[href], area[href]');
    if (!a || !(a instanceof HTMLAnchorElement)) return;
    const fixed = fixReal(hrefDesc.get.call(a));
    if (fixed) hrefDesc.set.call(a, fixed);
    retarget(a);
    if (shell && !e.defaultPrevented && effectiveTarget(a) === '_blank' && e.button === 0 && !a.hasAttribute('download')) {
      const url = SJ.decode(hrefDesc.get.call(a), ORIGIN);
      if (url) { e.preventDefault(); shell.openTab(url); }
    }
  };
  document.addEventListener('click', onClick, true);
  document.addEventListener('auxclick', onClick, true);
  // form.submit() fires no submit event, so retarget there too.
  for (const m of ['submit', 'requestSubmit']) {
    const orig = HTMLFormElement.prototype[m];
    if (orig) HTMLFormElement.prototype[m] = function (...a) { retarget(this); return orig.apply(this, a); };
  }
  document.addEventListener('submit', (e) => {
    const f = e.target;
    retarget(f);
    const actionAttr = getAttr.call(f, 'action');
    if (actionAttr) {
      const fixed = fixReal(new URL(actionAttr, realLoc.href).href);
      if (fixed) setAttr.call(f, 'action', fixed);
    }
  }, true);

  // ---- document identity
  hook(Document.prototype, 'URL', { get() { return target().href; } });
  hook(Document.prototype, 'documentURI', { get() { return target().href; } });
  hook(Document.prototype, 'referrer', { get(o) { return SJ.decode(o.call(this), ORIGIN) || ''; } });
  hook(Document.prototype, 'domain', { get() { return target().hostname; }, set() {} });
  hook(Node.prototype, 'baseURI', { get(o) { return dec(o.call(this)); } });
  Object.defineProperty(window, 'origin', { configurable: true, get: () => target().origin });
  hook(Document.prototype, 'cookie', {
    get(o) { return SJ.filterCookies(o.call(this), target().hostname); },
    set(v, o) {
      const c = SJ.rewriteSetCookie(v, target().hostname, realLoc.protocol === 'https:');
      if (c) o.call(this, c);
    },
  });

  // ---- cross-window messaging: the real origin is the proxy for everyone
  window.postMessage = function (msg, targetOrigin, transfer) {
    return nativePM.call(this, msg, fixTargetOrigin(targetOrigin), transfer);
  };
  hook(MessageEvent.prototype, 'origin', {
    get(o) {
      const v = o.call(this);
      if (v !== ORIGIN) return v;
      const src = rawSourceGet.call(this);
      const o2 = src ? winOrigin(src) : null;
      return o2 && !o2.startsWith('x-') ? o2 : target().origin;
    },
  });

  // ---- the page must not register or remove service workers on our origin
  if (window.ServiceWorkerContainer) {
    const S = ServiceWorkerContainer.prototype;
    S.register = () => Promise.reject(new DOMException('Service workers are disabled inside the proxy', 'SecurityError'));
    S.getRegistration = () => Promise.resolve(undefined);
    S.getRegistrations = () => Promise.resolve([]);
  }
})();
XCLOUD_FILE_END

# ---------------------------------------------------------------- HTTPS certificate
# Browsers only run the proxy (service worker + Microsoft sign-in crypto) over
# HTTPS or on localhost. We make a small local certificate authority once and
# a server certificate covering this machine's names and IPs on every run.
if [ "$TLS" = 1 ]; then
  if ! command -v openssl >/dev/null; then
    say "Installing openssl…"
    pkg_install openssl >/dev/null 2>&1 || true
  fi
  if command -v openssl >/dev/null; then
    mkdir -p "$APP/certs"; cd "$APP/certs"
    if [ ! -f ca.key ]; then
      openssl genrsa -out ca.key 2048 2>/dev/null
      openssl req -x509 -new -key ca.key -sha256 -days 3650 -subj "/CN=Cloud Gaming local CA" -out ca.crt 2>/dev/null
      NEW_CA=1
    fi
    HOSTN="$(hostname)"
    SAN="DNS:localhost,DNS:${HOSTN},DNS:${HOSTN}.local,IP:127.0.0.1"
    for ip in $(hostname -I 2>/dev/null || true); do case "$ip" in *:*) ;; *) SAN="$SAN,IP:$ip" ;; esac; done
    openssl genrsa -out server.key 2048 2>/dev/null
    openssl req -new -key server.key -subj "/CN=${HOSTN}" -out server.csr 2>/dev/null
    printf 'basicConstraints=CA:FALSE\nkeyUsage=digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\nsubjectAltName=%s\n' "$SAN" > server.ext
    openssl x509 -req -in server.csr -CA ca.crt -CAkey ca.key -CAcreateserial -days 825 -sha256 -extfile server.ext -out server.crt 2>/dev/null
    rm -f server.csr server.ext; chmod 600 ca.key server.key
    cd - >/dev/null
    say "HTTPS certificate ready"
  else
    warn "openssl isn't available; falling back to HTTP (only usable from this machine)."
    TLS=0; [ "$PORT" = 8443 ] && PORT=8080
  fi
fi
LOCAL_PORT=8080; [ "$PORT" = 8080 ] && LOCAL_PORT=8081
ENVV="PORT=$PORT"; [ "$TLS" = 1 ] && ENVV="$ENVV LOCAL_PORT=$LOCAL_PORT" || ENVV="$ENVV NO_TLS=1"

SCHEME=$([ "$TLS" = 1 ] && echo https || echo http)
IPS="$(hostname -I 2>/dev/null | tr ' ' '\n' | grep -v ':' | grep . || true)"
show_help() {
  echo
  printf '\033[1mOpen Xbox Cloud Gaming at:\033[0m\n'
  if [ "$TLS" = 1 ]; then
    echo "  this machine:    http://localhost:$LOCAL_PORT    (use this here; no certificate needed)"
  else
    echo "  this machine:    http://localhost:$PORT"
  fi
  for ip in $IPS; do echo "  other devices:   $SCHEME://$ip:$PORT"; done
  if [ "$TLS" = 1 ]; then
    echo
    printf '\033[1mOther devices (not this machine) must trust this file once:\033[0m %s\n' "$APP/certs/ca.crt"
    echo "  (You can also download it from $SCHEME://<address>:$PORT/ca.crt)"
    echo "  Windows:  double-click ca.crt > Install Certificate > Local Machine > Trusted Root Certification Authorities"
    echo "  macOS:    open in Keychain Access > System > set to Always Trust"
    echo "  ChromeOS: Settings > Privacy and security > Security > Manage certificates > Authorities > Import"
    echo "  Linux:    chrome://certificate-manager > Local certificates > Custom > Import"
    echo "  Clicking through a certificate warning is NOT enough; the browser has to trust it."
    [ "${NEW_CA:-0}" = 1 ] || echo "  (Same certificate authority as before, so devices that already trust it are fine.)"
  fi
  echo
}

# ---------------------------------------------------------------- run
if [ "$SERVICE" = 1 ]; then
  [ "$(id -u)" -eq 0 ] || die "Installing a service needs root: sudo $0 --service"
  command -v systemctl >/dev/null || die "systemd not found; run ./xcloud.sh directly instead."
  RUN_AS="${SUDO_USER:-root}"
  chown -R "$RUN_AS" "$APP" 2>/dev/null || true
  case "$ACCESS_PASSWORD" in *'"'*|*'\'*|*'%'*) die 'Password cannot contain " \ or %' ;; esac
  cat > /etc/systemd/system/xcloud.service <<UNIT
[Unit]
Description=Xbox Cloud Gaming proxy
After=network-online.target
Wants=network-online.target

[Service]
User=$RUN_AS
WorkingDirectory=$APP
Environment=$ENVV
$( [ -n "$ACCESS_PASSWORD" ] && printf 'Environment="ACCESS_PASSWORD=%s"' "$ACCESS_PASSWORD" )
ExecStart=$NODE $APP/server.js
Restart=always
RestartSec=2

[Install]
WantedBy=multi-user.target
UNIT
  systemctl daemon-reload
  systemctl enable xcloud >/dev/null 2>&1
  systemctl restart xcloud
  sleep 1
  systemctl is-active --quiet xcloud && say "Service running and set to start on boot." || die "Service failed: journalctl -u xcloud -n 50"
  echo "  logs: journalctl -u xcloud -f    stop: sudo systemctl stop xcloud    remove: sudo $0 --uninstall"
  show_help
  exit 0
fi

show_help
say "Starting (Ctrl+C to stop)…"
cd "$APP"
export ACCESS_PASSWORD
[ -n "$ACCESS_PASSWORD" ] && say "Password protection is on" || warn "No password set. Anyone who can reach this address can use it (add --password=...)."
exec env $ENVV "$NODE" server.js
