/* Injected at the top of every proxied document. Makes the page believe it
 * lives at its target URL and routes anything URL-shaped back through /p/. */
(function () {
  'use strict';
  if (window.__sjClient) return;
  Object.defineProperty(window, '__sjClient', { value: true });

  const SJ = self.SJ;
  // Take the two injected <script> tags back out once they've run, so the
  // document's structure matches the server's HTML exactly (React compares).
  // (An import map stays in effect after its element is removed.)
  for (const el of document.querySelectorAll('script[data-sj]')) el.remove();
  const ORIGIN = location.origin;
  const realLoc = location;
  SJ.install(window);

  const desc = (o, p) => {
    for (let x = o; x; x = Object.getPrototypeOf(x)) {
      const d = Object.getOwnPropertyDescriptor(x, p);
      if (d) return d;
    }
    return null;
  };
  const baseGet = desc(Node.prototype, 'baseURI').get;
  const hrefDesc = desc(HTMLAnchorElement.prototype, 'href'); // unhooked
  const rawTextSet = desc(Node.prototype, 'textContent').set;
  // Called first by rewritten inline scripts: restore the original source
  // text on the element so frameworks that compare it (React hydration) match.
  Object.defineProperty(window, '__sjRestore', {
    value: (el, text) => { if (el) rawTextSet.call(el, text); },
  });

  const target = () => new URL(SJ.decode(realLoc.href, ORIGIN));
  const targetBase = () => SJ.decode(baseGet.call(document), ORIGIN) || target().href;
  const enc = (u) => SJ.encodeUrl(String(u), targetBase());
  const dec = (u) => (u == null ? u : SJ.decode(u, ORIGIN) ?? u);

  // Redefine an accessor on `proto` (looking it up the prototype chain).
  function hook(proto, prop, { get, set }) {
    const d = desc(proto, prop);
    if (!d || !d.get) return;
    Object.defineProperty(proto, prop, {
      configurable: true,
      enumerable: d.enumerable,
      get: get ? function () { return get.call(this, d.get); } : d.get,
      set: set && d.set ? function (v) { set.call(this, v, d.set); } : d.set,
    });
  }

  // ---- passkeys
  // A passkey is tied to the real site's domain (login.live.com), but every
  // proxied page really runs on this proxy's address, so the browser always
  // refuses it. Microsoft's sign-in tries passkeys first (passkey autofill,
  // "sign in with a passkey"), above all for Outlook/Hotmail accounts, many of
  // which are passwordless, and the sign-in then gets stuck. Look like a
  // browser without passkey support, so it offers the password, an emailed
  // code or the Authenticator app instead.
  try { Object.defineProperty(window, 'PublicKeyCredential', { configurable: true, writable: true, value: undefined }); } catch { /* ignore */ }
  if (window.CredentialsContainer) {
    const CC = CredentialsContainer.prototype;
    for (const m of ['get', 'create']) {
      const orig = CC[m];
      if (typeof orig !== 'function') continue;
      CC[m] = function (opts) {
        if (opts && opts.publicKey) return Promise.reject(new DOMException('Passkeys are not available through the proxy.', 'NotAllowedError'));
        return orig.apply(this, arguments);
      };
    }
  }

  // ---- per-site storage
  // Every proxied page really shares the proxy's one origin, so without
  // this, all sites would share one localStorage/IndexedDB. Sites then
  // overwrite or delete each other's data. Xbox in particular: www.xbox.com
  // (loaded in a hidden frame) computes the same storage key as
  // play.xbox.com and deletes its saved sign-in tokens. Give each site
  // its own namespace, as a real browser does.
  const SITE = target().origin + '|';
  function partitionStorage(name) {
    let real;
    try { real = window[name]; } catch { return; }
    if (!real) return;
    const keys = () => {
      const out = [];
      for (let i = 0; i < real.length; i++) { const k = real.key(i); if (k && k.startsWith(SITE)) out.push(k.slice(SITE.length)); }
      return out;
    };
    // (configurable, so the Proxy may hide them from Object.keys)
    const api = Object.create(Storage.prototype, {
      getItem: { value: (k) => real.getItem(SITE + k), configurable: true },
      setItem: { value: (k, v) => real.setItem(SITE + k, String(v)), configurable: true },
      removeItem: { value: (k) => real.removeItem(SITE + k), configurable: true },
      clear: { value: () => { for (const k of keys()) real.removeItem(SITE + k); }, configurable: true },
      key: { value: (i) => { const k = keys()[i]; return k === undefined ? null : k; }, configurable: true },
      length: { get: () => keys().length, configurable: true },
    });
    const own = (k) => typeof k === 'symbol' || k in api;
    const proxy = new Proxy(api, {
      get(t, k) { if (own(k)) return Reflect.get(t, k); const v = real.getItem(SITE + k); return v === null ? undefined : v; },
      set(t, k, v) { if (own(k)) return false; real.setItem(SITE + k, String(v)); return true; },
      has(t, k) { return own(k) || real.getItem(SITE + k) !== null; },
      deleteProperty(t, k) { if (!own(k)) real.removeItem(SITE + k); return true; },
      ownKeys() { return keys(); },
      getOwnPropertyDescriptor(t, k) {
        if (own(k)) return undefined;
        const v = real.getItem(SITE + k);
        return v === null ? undefined : { value: v, writable: true, enumerable: true, configurable: true };
      },
    });
    try { Object.defineProperty(window, name, { configurable: true, enumerable: true, get: () => proxy }); } catch { /* leave shared */ }
  }
  partitionStorage('localStorage');
  partitionStorage('sessionStorage');
  hook(StorageEvent.prototype, 'key', {
    get(o) { const k = o.call(this); return typeof k === 'string' && k.startsWith(SITE) ? k.slice(SITE.length) : k; },
  });
  if (window.IDBFactory) {
    const F = IDBFactory.prototype;
    const idbOpen = F.open, idbDelete = F.deleteDatabase, idbList = F.databases;
    F.open = function (n, ...rest) { return idbOpen.call(this, SITE + n, ...rest); };
    F.deleteDatabase = function (n) { return idbDelete.call(this, SITE + n); };
    if (idbList) {
      F.databases = function () {
        return idbList.call(this).then((l) => l.filter((d) => d.name.startsWith(SITE)).map((d) => ({ ...d, name: d.name.slice(SITE.length) })));
      };
    }
    hook(IDBDatabase.prototype, 'name', {
      get(o) { const n = o.call(this); return n.startsWith(SITE) ? n.slice(SITE.length) : n; },
    });
  }
  if (window.CacheStorage) {
    const C = CacheStorage.prototype;
    for (const m of ['open', 'has', 'delete']) {
      const orig = C[m];
      C[m] = function (n, ...rest) { return orig.call(this, SITE + n, ...rest); };
    }
    const cKeys = C.keys;
    C.keys = function () { return cKeys.call(this).then((l) => l.filter((n) => n.startsWith(SITE)).map((n) => n.slice(SITE.length))); };
  }
  if (window.BroadcastChannel) {
    const RealBC = BroadcastChannel;
    window.BroadcastChannel = new Proxy(RealBC, { construct(t, args, nt) { args[0] = SITE + args[0]; return Reflect.construct(t, args, nt); } });
    hook(RealBC.prototype, 'name', { get(o) { const n = o.call(this); return n.startsWith(SITE) ? n.slice(SITE.length) : n; } });
  }

  // ---- same-origin policy between proxied frames/windows
  // Every proxied page really shares the proxy's origin, so one frame could
  // read another's address even when they show different sites. Sign-in
  // libraries (MSAL) rely on that read *throwing* until their hidden frame
  // is back on their own site, so other windows are handed out wrapped:
  // while the window shows a different site, reading its location or
  // document throws SecurityError like a real browser. Navigating it and
  // postMessage keep working.
  const rawSourceGet = desc(MessageEvent.prototype, 'source').get;
  // Every proxied page's real origin is the proxy's, so a targetOrigin naming
  // the site would never match: send to '*' instead.
  const nativePM = window.postMessage;
  Object.defineProperty(window, '__sj$pm', { value: nativePM });
  function fixTargetOrigin(o) {
    if (o && typeof o === 'object') return Object.assign({}, o, { targetOrigin: '*' });
    return typeof o === 'string' && o !== '/' ? '*' : o;
  }
  function winOrigin(w) {
    try {
      const h = w.location.href; // real location (this file isn't rewritten)
      const t = SJ.decode(h, ORIGIN);
      if (t) return new URL(t).origin;
      if (h === '' || h.startsWith('about:')) return null; // inherits its creator's origin
      return 'x-other:' + new URL(h).origin;
    } catch { return 'x-unreachable'; }
  }
  const isCross = (w) => { const o = winOrigin(w); return o !== null && o !== target().origin; };
  const secErr = () => new DOMException('Blocked a frame from accessing a cross-origin frame.', 'SecurityError');
  function crossLocation(w) {
    const nav = (u, replace) => {
      const dest = SJ.rewriteUrlAttr(String(u), targetBase());
      replace ? w.location.replace(dest) : (w.location.href = dest);
    };
    const o = {};
    for (const k of ['hash', 'host', 'hostname', 'origin', 'pathname', 'port', 'protocol', 'search', 'ancestorOrigins']) {
      Object.defineProperty(o, k, { get() { throw secErr(); } });
    }
    Object.defineProperty(o, 'href', { get() { throw secErr(); }, set(v) { nav(v); } });
    o.replace = (u) => nav(u, true);
    o.assign = (u) => nav(u);
    o.reload = () => { throw secErr(); };
    o.toString = () => { throw secErr(); };
    return o;
  }
  const wrappedWins = new WeakMap();
  const winProxies = new WeakSet();
  function wrapWin(w) {
    if (!w || w === window || winProxies.has(w)) return w;
    try { if (w.window !== w) return w; } catch { return w; }
    let p = wrappedWins.get(w);
    if (p) return p;
    const bound = new Map();
    p = new Proxy(w, {
      get(t, k) {
        if (k === '__sjLocation' || k === 'location') {
          if (isCross(t)) return crossLocation(t);
          const l = Reflect.get(t, '__sjLocation');
          return l === undefined ? t.location : l;
        }
        if (k === 'document' && isCross(t)) throw secErr();
        if (k === 'postMessage') {
          // Called through this realm's function, so the receiver's
          // event.source is this window (the target's own patched
          // postMessage would make it the target itself).
          let b = bound.get(k);
          if (!b) {
            b = { b: function (msg, targetOrigin, transfer) {
              const native = t.__sj$pm || Reflect.get(t, 'postMessage');
              return native.call(t, msg, fixTargetOrigin(targetOrigin), transfer);
            } };
            bound.set(k, b);
          }
          return b.b;
        }
        const v = Reflect.get(t, k);
        if (typeof v === 'function' && typeof k === 'string' && !/^[A-Z]/.test(k)) {
          let b = bound.get(k);
          if (!b || b.f !== v) { b = { f: v, b: v.bind(t) }; bound.set(k, b); }
          return b.b; // window methods (postMessage, close, ...) need the real window as `this`
        }
        return v;
      },
      set(t, k, v) {
        if (k === '__sjLocation' || k === 'location') {
          if (isCross(t)) crossLocation(t).href = v;
          else if (!Reflect.set(t, '__sjLocation', v)) t.location.href = SJ.rewriteUrlAttr(String(v), targetBase());
          return true;
        }
        if (isCross(t)) throw secErr();
        return Reflect.set(t, k, v);
      },
    });
    winProxies.add(p);
    wrappedWins.set(w, p);
    return p;
  }
  // top / parent (see install() in rewrite.js) also hand out wrapped windows.
  Object.defineProperty(window, '__sjWrapWin', { value: wrapWin });
  for (const C of ['HTMLIFrameElement', 'HTMLFrameElement', 'HTMLObjectElement']) {
    if (!window[C]) continue;
    hook(window[C].prototype, 'contentWindow', { get(o) { return wrapWin(o.call(this)); } });
    hook(window[C].prototype, 'contentDocument', {
      get(o) { const d = o.call(this); return d && d.defaultView && isCross(d.defaultView) ? null : d; },
    });
  }
  hook(MessageEvent.prototype, 'source', {
    get(o) { const s = o.call(this); try { return s && s.window === s ? wrapWin(s) : s; } catch { return s; } },
  });
  try { hook(window, 'opener', { get(o) { return wrapWin(o.call(this)); } }); } catch { /* not redefinable here */ }

  // ---- URL-bearing element properties
  const URL_PROPS = [
    ['HTMLAnchorElement', 'href'], ['HTMLAreaElement', 'href'], ['HTMLLinkElement', 'href'],
    ['HTMLBaseElement', 'href'], ['HTMLFormElement', 'action'], ['HTMLButtonElement', 'formAction'],
    ['HTMLInputElement', 'formAction'], ['HTMLIFrameElement', 'src'], ['HTMLFrameElement', 'src'],
    ['HTMLScriptElement', 'src'], ['HTMLImageElement', 'src'], ['HTMLSourceElement', 'src'],
    ['HTMLMediaElement', 'src'], ['HTMLEmbedElement', 'src'], ['HTMLTrackElement', 'src'],
    ['HTMLInputElement', 'src'], ['HTMLObjectElement', 'data'], ['HTMLVideoElement', 'poster'],
  ];
  for (const [ctor, prop] of URL_PROPS) {
    if (!window[ctor]) continue;
    hook(window[ctor].prototype, prop, {
      get(o) { return dec(o.call(this)); },
      set(v, o) { o.call(this, SJ.rewriteUrlAttr(v, targetBase())); },
    });
  }
  for (const ctor of ['HTMLImageElement', 'HTMLSourceElement']) {
    hook(window[ctor].prototype, 'srcset', { set(v, o) { o.call(this, SJ.rewriteSrcset(v, targetBase())); } });
  }
  // a.host, a.pathname, ... should describe the target URL too.
  for (const ctor of ['HTMLAnchorElement', 'HTMLAreaElement']) {
    for (const p of ['origin', 'protocol', 'host', 'hostname', 'port', 'pathname']) {
      hook(window[ctor].prototype, p, {
        get(o) { try { return new URL(this.href)[p]; } catch { return o.call(this); } },
      });
    }
  }

  // ---- attributes
  const E = Element.prototype;
  const setAttr = E.setAttribute, getAttr = E.getAttribute;
  E.setAttribute = function (name, value) {
    const n = String(name).toLowerCase();
    let v = String(value);
    const tag = this.tagName.toLowerCase();
    if (n === 'integrity') return;
    if (SJ.isUrlAttr(tag, n)) v = SJ.rewriteUrlAttr(v, targetBase());
    else if (n === 'srcset' || n === 'imagesrcset') v = SJ.rewriteSrcset(v, targetBase());
    else if (n.startsWith('on')) v = SJ.rewriteJs(v);
    return setAttr.call(this, name, v);
  };
  E.getAttribute = function (name) {
    const v = getAttr.call(this, name);
    return v != null && SJ.isUrlAttr(this.tagName.toLowerCase(), String(name).toLowerCase()) ? dec(v) : v;
  };

  // ---- HTML and script text injection
  const isScript = (el) => el instanceof HTMLScriptElement;
  hook(E, 'innerHTML', {
    set(v, o) {
      if (isScript(this)) o.call(this, SJ.rewriteJs(v));
      else if (this instanceof HTMLStyleElement) o.call(this, v);
      else o.call(this, SJ.rewriteHtml(String(v), targetBase()));
    },
  });
  hook(E, 'outerHTML', { set(v, o) { o.call(this, SJ.rewriteHtml(String(v), targetBase())); } });
  const iah = E.insertAdjacentHTML;
  E.insertAdjacentHTML = function (pos, html) { return iah.call(this, pos, SJ.rewriteHtml(String(html), targetBase())); };
  for (const m of ['write', 'writeln']) {
    const orig = Document.prototype[m];
    Document.prototype[m] = function (...a) { return orig.call(this, SJ.rewriteHtml(a.join(''), targetBase())); };
  }
  for (const p of ['text', 'textContent', 'innerText']) {
    const d = desc(HTMLScriptElement.prototype, p);
    if (!d) continue;
    Object.defineProperty(HTMLScriptElement.prototype, p, {
      configurable: true,
      get() { return d.get.call(this); },
      set(v) { d.set.call(this, SJ.rewriteJs(String(v))); },
    });
  }
  const append = Node.prototype.appendChild;
  Node.prototype.appendChild = function (child) {
    if (isScript(this) && child && child.nodeType === 3) child.data = SJ.rewriteJs(child.data);
    return append.call(this, child);
  };

  // ---- strings evaluated as code (direct eval is left alone: wrapping it breaks scoping)
  for (const t of ['setTimeout', 'setInterval']) {
    const orig = window[t];
    window[t] = function (fn, ...rest) { return orig.call(this, typeof fn === 'string' ? SJ.rewriteJs(fn) : fn, ...rest); };
  }
  const RealFunction = Function;
  const ProxyFunction = function (...args) {
    if (args.length) args[args.length - 1] = SJ.rewriteJs(String(args[args.length - 1]));
    return RealFunction.apply(this, args);
  };
  ProxyFunction.prototype = RealFunction.prototype;
  Object.defineProperty(RealFunction.prototype, 'constructor', { value: ProxyFunction, configurable: true, writable: true });
  window.Function = ProxyFunction;

  // ---- network
  const realFetch = window.fetch;
  window.fetch = function (input, init) {
    if (typeof input === 'string' || input instanceof URL) input = enc(input);
    return realFetch.call(this, input, init);
  };
  hook(Response.prototype, 'url', { get(o) { return dec(o.call(this)); } });
  const xhrOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) { return xhrOpen.call(this, method, enc(url), ...rest); };
  hook(XMLHttpRequest.prototype, 'responseURL', { get(o) { return dec(o.call(this)); } });
  if (navigator.sendBeacon) {
    const beacon = navigator.sendBeacon;
    navigator.sendBeacon = function (url, data) { return beacon.call(navigator, enc(url), data); };
  }
  const wrapCtor = (name, fix) => {
    if (!window[name]) return;
    window[name] = new Proxy(window[name], { construct(t, args, nt) { fix(args); return Reflect.construct(t, args, nt); } });
  };
  wrapCtor('EventSource', (a) => { a[0] = enc(a[0]); });
  wrapCtor('Worker', (a) => { a[0] = enc(a[0]); });
  wrapCtor('SharedWorker', (a) => { a[0] = enc(a[0]); });
  wrapCtor('WebSocket', (a) => {
    const u = new URL(String(a[0]), targetBase());
    if (u.protocol === 'https:') u.protocol = 'wss:';
    else if (u.protocol === 'http:') u.protocol = 'ws:';
    a[0] = (realLoc.protocol === 'https:' ? 'wss://' : 'ws://') + realLoc.host +
      '/__sj/ws?url=' + encodeURIComponent(u.href) + '&origin=' + encodeURIComponent(target().origin);
  });
  hook(WebSocket.prototype, 'url', {
    get(o) {
      const v = o.call(this);
      try { return new URL(v).searchParams.get('url') || v; } catch { return v; }
    },
  });

  // ---- navigation
  // The tabbed UI, if this page is running inside it.
  let shell = null, inShellTab = false;
  try {
    for (let w = window; w.parent !== w; w = w.parent) {
      if (w.parent.__sjShell) { shell = w.parent.__sjShell; inShellTab = w === window; break; }
    }
  } catch { /* not ours */ }
  const absTarget = (u) => new URL(String(u), targetBase()).href;
  if (shell && shell.report) {
    const where = () => { try { return target().href; } catch { return ''; } };
    window.addEventListener('error', (e) => {
      if (e.message) shell.report({ kind: 'error', url: where(), detail: e.message + (e.filename ? ' @ ' + (dec(e.filename) || e.filename) + ':' + e.lineno : '') });
    });
    // Xbox's sign-in errors carry the real reason in `cause`, which its
    // telemetry drops. Its error classes call Error.captureStackTrace, so
    // look at auth-related errors as they are created and report the chain.
    if (typeof Error.captureStackTrace === 'function') {
      const cst = Error.captureStackTrace;
      const seen = new Set();
      const AUTH = /xbox ?token|xbox user token|sisu|xsts|relying ?party|msa|sign.?in|create user|hydrat|proof ?key|signature|nsal/i;
      const chain = (e) => {
        const parts = [];
        for (let c = e, i = 0; c && i < 6; c = c.cause, i++) {
          if (typeof c !== 'object') { parts.push(String(c)); break; }
          let p = `${c.name || c.constructor && c.constructor.name || 'Error'}: ${c.message || ''}`;
          for (const k of ['type', 'errorCode', 'subError', 'status', 'statusCode', 'xErrorCode', 'authFailureStage', 'url']) {
            if (c[k] != null && typeof c[k] !== 'object') p += ` [${k}=${String(c[k]).slice(0, 120)}]`;
          }
          parts.push(p);
        }
        return parts.join(' <- caused by ');
      };
      Error.captureStackTrace = function (err, ...rest) {
        const r = cst.call(this, err, ...rest);
        try {
          if (err && AUTH.test(String(err.message || '') + ' ' + String(err.type || '')) && err.cause) {
            // the cause is attached by the time the constructor returns
            queueMicrotask(() => {
              try {
                const text = chain(err);
                if (!seen.has(text) && seen.size < 40) { seen.add(text); shell.report({ kind: 'error', url: where(), detail: '[auth error] ' + text }); }
              } catch { /* ignore */ }
            });
          }
        } catch { /* never break error creation */ }
        return r;
      };
    }
    // React logs errors caught by error boundaries with console.error.
    const cerr = console.error;
    let sent = 0;
    const fmt = (a) => {
      if (a instanceof Error) {
        const frames = String(a.stack || '').split('\n').slice(1, 4)
          .map((l) => l.trim().replace(/https?:\/\/[^\s)]*\/p\/(https?:\/\/)/g, '$1')).join(' < ');
        return `${a.name}: ${a.message}${frames ? ' | ' + frames : ''}`;
      }
      if (typeof a === 'string') return a;
      try { return JSON.stringify(a).slice(0, 200); } catch { return String(a); }
    };
    console.error = function (...args) {
      try {
        if (sent < 60) {
          const text = args.map(fmt).join(' ').replace(/\s+/g, ' ').slice(0, 600);
          if (!/Failed to load resource/.test(text)) { sent++; shell.report({ kind: 'error', url: where(), detail: '[console] ' + text }); }
        }
      } catch { /* never break logging */ }
      return cerr.apply(this, args);
    };
    window.addEventListener('unhandledrejection', (e) => {
      const r = e.reason;
      shell.report({ kind: 'error', url: where(), detail: 'Unhandled: ' + (r && (r.stack || r.message) || String(r)).split('\n').slice(0, 3).join(' ') });
    });
  }

  const open = window.open;
  window.open = function (url, name, features) {
    // Plain new-window calls become tabs; real popups (with features) stay popups.
    if (shell && url && !features && (!name || name === '_blank')) {
      try { return wrapWin(shell.openTab(absTarget(url))); } catch { /* fall through */ }
    }
    return wrapWin(open.call(this, url ? SJ.rewriteUrlAttr(url, targetBase()) : url, name, features));
  };
  for (const m of ['pushState', 'replaceState']) {
    const orig = History.prototype[m];
    History.prototype[m] = function (state, title, url) {
      return url == null ? orig.call(this, state, title) : orig.call(this, state, title, enc(url));
    };
  }
  // Last line of defense for links/forms whose URLs escaped rewriting.
  const fixReal = (real) => {
    if (!/^https?:/i.test(real) || real.startsWith(ORIGIN + SJ.PREFIX)) return null;
    const u = new URL(real);
    return SJ.PREFIX + (u.origin === ORIGIN ? new URL(u.pathname + u.search + u.hash, target().origin).href : real);
  };
  const effectiveTarget = (el) => {
    const t = getAttr.call(el, 'target');
    if (t != null) return t.toLowerCase();
    const b = document.querySelector('base[target]');
    return b ? getAttr.call(b, 'target').toLowerCase() : '';
  };
  // In a UI tab, _top/_parent would replace the whole browser UI.
  const retarget = (el) => {
    const t = effectiveTarget(el);
    if (inShellTab && (t === '_top' || t === '_parent')) setAttr.call(el, 'target', '_self');
  };
  const onClick = (e) => {
    const a = e.target && e.target.closest && e.target.closest('a[href], area[href]');
    if (!a || !(a instanceof HTMLAnchorElement)) return;
    const fixed = fixReal(hrefDesc.get.call(a));
    if (fixed) hrefDesc.set.call(a, fixed);
    retarget(a);
    if (shell && !e.defaultPrevented && effectiveTarget(a) === '_blank' && e.button === 0 && !a.hasAttribute('download')) {
      const url = SJ.decode(hrefDesc.get.call(a), ORIGIN);
      if (url) { e.preventDefault(); shell.openTab(url); }
    }
  };
  document.addEventListener('click', onClick, true);
  document.addEventListener('auxclick', onClick, true);
  // form.submit() fires no submit event, so retarget there too.
  for (const m of ['submit', 'requestSubmit']) {
    const orig = HTMLFormElement.prototype[m];
    if (orig) HTMLFormElement.prototype[m] = function (...a) { retarget(this); return orig.apply(this, a); };
  }
  document.addEventListener('submit', (e) => {
    const f = e.target;
    retarget(f);
    const actionAttr = getAttr.call(f, 'action');
    if (actionAttr) {
      const fixed = fixReal(new URL(actionAttr, realLoc.href).href);
      if (fixed) setAttr.call(f, 'action', fixed);
    }
  }, true);

  // ---- document identity
  hook(Document.prototype, 'URL', { get() { return target().href; } });
  hook(Document.prototype, 'documentURI', { get() { return target().href; } });
  hook(Document.prototype, 'referrer', { get(o) { return SJ.decode(o.call(this), ORIGIN) || ''; } });
  hook(Document.prototype, 'domain', { get() { return target().hostname; }, set() {} });
  hook(Node.prototype, 'baseURI', { get(o) { return dec(o.call(this)); } });
  Object.defineProperty(window, 'origin', { configurable: true, get: () => target().origin });
  hook(Document.prototype, 'cookie', {
    get(o) { return SJ.filterCookies(o.call(this), target().hostname); },
    set(v, o) {
      const c = SJ.rewriteSetCookie(v, target().hostname, realLoc.protocol === 'https:');
      if (c) o.call(this, c);
    },
  });

  // ---- cross-window messaging: the real origin is the proxy for everyone
  window.postMessage = function (msg, targetOrigin, transfer) {
    return nativePM.call(this, msg, fixTargetOrigin(targetOrigin), transfer);
  };
  hook(MessageEvent.prototype, 'origin', {
    get(o) {
      const v = o.call(this);
      if (v !== ORIGIN) return v;
      const src = rawSourceGet.call(this);
      const o2 = src ? winOrigin(src) : null;
      return o2 && !o2.startsWith('x-') ? o2 : target().origin;
    },
  });

  // ---- the page must not register or remove service workers on our origin
  if (window.ServiceWorkerContainer) {
    const S = ServiceWorkerContainer.prototype;
    S.register = () => Promise.reject(new DOMException('Service workers are disabled inside the proxy', 'SecurityError'));
    S.getRegistration = () => Promise.resolve(undefined);
    S.getRegistrations = () => Promise.resolve([]);
  }
})();
