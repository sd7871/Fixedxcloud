/* Service worker: routes every request made by a proxied page through the relay. */
importScripts('/__sj/rewrite.js');

const { PREFIX } = self.SJ;
// Injected at the top of every proxied page (client.js removes these tags
// again after running so the DOM matches the server's HTML). The import map
// makes root-relative module paths ("/assets/x.js") resolve straight to the
// proxied URL. Without it they'd arrive via a redirect, and browsers key
// modules by the requested URL, so one module could load and run twice.
function inject(target) {
  // Already-proxied URLs map to themselves. The keys end in "//" so the rest
  // resolves as a relative path (import maps reject mappings that escape).
  const map = { imports: { '/': PREFIX + target.origin + '/', [PREFIX + 'https://']: PREFIX + 'https://', [PREFIX + 'http://']: PREFIX + 'http://', '/__sj/': '/__sj/' } };
  return '<script type="importmap" data-sj="">' + JSON.stringify(map).replace(/</g, '\\u003c') + '</script>' +
    '<script src="/__sj/rewrite.js" data-sj=""></script><script src="/__sj/client.js" data-sj=""></script>';
}
const NULL_BODY = new Set([101, 103, 204, 205, 304]);
const REDIRECTS = new Set([301, 302, 303, 307, 308]);
const PRELUDE = '(' + self.SJ.install.toString() + ')(self);\n';

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

// Problems are shown in the app's "Problems" panel (analytics noise is skipped).
const NOISE = /events\.data\.microsoft|browser\.pipe\.aria|sentry\.io|fpt\.live\.com|clarity\.ms|demdex\.net|omtrdc\.net|doubleclick|google-analytics/;
function report(entry) {
  if (NOISE.test(entry.url || '')) return;
  self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((cs) => {
    for (const c of cs) if (!new URL(c.url).pathname.startsWith(PREFIX)) c.postMessage({ sjDiag: entry });
  });
}

self.addEventListener('fetch', (e) => {
  e.respondWith(route(e).catch((err) => {
    report({ kind: 'request', status: 'failed', url: e.request.url, detail: String(err && err.message || err) });
    return new Response('Proxy error: ' + (err && err.message || err), { status: 502, headers: { 'content-type': 'text/plain' } });
  }));
});

// Target URL for a proxy-origin URL, or null.
function targetOf(str) {
  try {
    const u = new URL(str);
    if (u.origin !== self.location.origin || !u.pathname.startsWith(PREFIX)) return null;
    let rest = u.href.slice(u.origin.length + PREFIX.length);
    if (!/^[a-z][\w+.-]*:/i.test(rest)) rest = 'https://' + rest;
    const t = new URL(rest);
    return /^https?:$/.test(t.protocol) ? t : null;
  } catch { return null; }
}

// The target URL of the page (or worker) that issued this request.
async function requesterTarget(e) {
  if (e.clientId) {
    const c = await self.clients.get(e.clientId);
    if (c) { const t = targetOf(c.url); if (t) return t; }
  }
  return e.request.referrer ? targetOf(e.request.referrer) : null;
}

// Xbox sends its own crash reports (Sentry) and telemetry exceptions
// (Microsoft 1DS). They pass through here, so read them and show the errors
// in the Problems panel: errors caught by the app's own "Something went
// wrong" screens never reach the page's error events.
const CRASH_REPORT = /(^|\.)ingest(\.[a-z]+)?\.sentry\.io$|^browser\.events\.data\.microsoft\.com$|^[a-z0-9-]+\.events\.data\.microsoft\.com$/;
function readCrashReports(target, req, pageUrl) {
  if (req.method !== 'POST' || !CRASH_REPORT.test(target.hostname)) return;
  req.clone().text().then((text) => {
    for (const line of text.split('\n')) {
      let o;
      try { o = JSON.parse(line); } catch { continue; }
      if (o && o.exception && Array.isArray(o.exception.values)) {
        for (const v of o.exception.values) {
          const frames = ((v.stacktrace && v.stacktrace.frames) || []).slice(-4).reverse()
            .map((f) => `${f.function || '?'} ${String(f.filename || '').split('/').pop()}:${f.lineno || '?'}`).join(' < ');
          report({ kind: 'error', url: (o.request && o.request.url) || pageUrl, detail: `[crash report] ${v.type || 'Error'}: ${v.value || ''}${frames ? ' | ' + frames : ''}` });
        }
      } else if (o && typeof o.name === 'string' && /exception|error|fail/i.test(o.name) && !/performance/i.test(o.name)) {
        const d = summarizeTelemetry(o.data || o.baseData || {});
        if (d) report({ kind: 'error', url: pageUrl, detail: '[telemetry] ' + d });
      }
    }
  }).catch(() => {});
}

// Keep what explains an error; drop the fields every event repeats.
const TELEMETRY_BOILERPLATE = new Set(['webAppVersion', 'webAppSessionId', 'isWebServer', 'activeUserXuid', 'route',
  'webFlightRing', 'deviceId', 'infraHost', 'density', 'level', 'timestamp']);
function summarizeTelemetry(d) {
  if (typeof d === 'string') { try { d = JSON.parse(d); } catch { return d.slice(0, 1500); } }
  const msg = String(d.message || '');
  if (/^No transformed data for query key/.test(msg)) return ''; // follow-on noise
  const out = [];
  if (d.errorType) out.push(d.errorType);
  if (msg) out.push(msg);
  if (d.context && d.context.tag) out.push('in ' + d.context.tag);
  const rest = {};
  for (const [k, v] of Object.entries(d)) {
    if (TELEMETRY_BOILERPLATE.has(k) || k === 'errorType' || k === 'message') continue;
    if (k === 'context' && v && typeof v === 'object') {
      const c = { ...v }; delete c.tag; delete c.timestamp;
      if (Object.keys(c).length) rest.context = c;
      continue;
    }
    rest[k] = v;
  }
  if (Object.keys(rest).length) out.push(JSON.stringify(rest).replace(/\\n/g, ' ').slice(0, 1500));
  return out.join(' | ');
}

async function route(e) {
  const req = e.request;
  const url = new URL(req.url);
  const same = url.origin === self.location.origin;

  if (same) {
    if (url.pathname.startsWith(PREFIX)) {
      const t = targetOf(req.url);
      if (!t) return new Response('Bad proxied URL', { status: 400 });
      return proxy(e, req, t);
    }
    if (url.pathname.startsWith('/__sj/') || url.pathname === '/sw.js') return fetch(req);
  } else if (!/^https?:$/.test(url.protocol)) {
    return fetch(req);
  }

  // Not a /p/ URL. If a proxied page asked for it, it escaped rewriting.
  const from = await requesterTarget(e);
  if (!from) return fetch(req);
  if (same) {
    // Root-relative URL like /api: re-root it on the target's origin.
    return Response.redirect(PREFIX + new URL(url.pathname + url.search, from.origin).href, 307);
  }
  return proxy(e, req, url, from); // absolute cross-origin subresource
}

function site(host) { return host.split('.').slice(-2).join('.'); }

async function proxy(e, req, target, from) {
  if (from === undefined) from = await requesterTarget(e);
  readCrashReports(target, req, from ? from.href : '');
  const headers = new Headers(req.headers);

  // Referer, as the default strict-origin-when-cross-origin policy would send it.
  let ref = null;
  if (req.referrer) {
    ref = targetOf(req.referrer);
    if (!ref) { const r = new URL(req.referrer); if (r.origin !== self.location.origin) ref = r; }
  }
  if (ref) headers.set('x-sj-referer', ref.origin === target.origin ? ref.href : ref.origin + '/');

  // Origin header: browsers send it on every non-GET/HEAD request and on
  // cross-origin CORS requests. Through the proxy everything is same-origin,
  // so reconstruct it from the requesting page.
  const initiator = from || ref;
  if (initiator) {
    const o = initiator.origin;
    if ((req.method !== 'GET' && req.method !== 'HEAD') || (req.mode === 'cors' && o !== target.origin)) headers.set('x-sj-origin', o);
  }

  // Sec-Fetch-* as the browser would have sent them to the real site.
  let fetchSite = 'none';
  if (initiator) fetchSite = initiator.origin === target.origin ? 'same-origin' : site(initiator.hostname) === site(target.hostname) ? 'same-site' : 'cross-site';
  headers.set('x-sj-fetch-site', fetchSite);
  headers.set('x-sj-fetch-mode', req.mode === 'navigate' ? 'navigate' : req.mode);
  headers.set('x-sj-fetch-dest', req.destination || 'empty');

  const init = {
    method: req.method,
    headers,
    credentials: 'same-origin',
    redirect: 'manual',
    cache: req.cache === 'only-if-cached' ? 'default' : req.cache,
  };
  if (req.method !== 'GET' && req.method !== 'HEAD') init.body = await req.arrayBuffer();

  const res = await fetch('/__sj/relay?url=' + encodeURIComponent(target.href), init);
  // Trace every sign-in / token request, successful or not, so the
  // Problems panel shows whether the token exchange happens at all.
  if (/(^|\.)auth\.xboxlive\.com$|^sisu\.xboxlive\.com$|^title\.mgt\.xboxlive\.com$/.test(target.hostname) ||
      (/^login\.(live|microsoftonline)\.com$/.test(target.hostname) && /token/i.test(target.pathname))) {
    let note = '';
    if (res.status >= 400) {
      try { note = ' \u2014 ' + (await res.clone().text()).replace(/\s+/g, ' ').slice(0, 300); } catch { /* ignore */ }
      const xerr = res.headers.get('x-err') || res.headers.get('www-authenticate');
      if (xerr) note += ` [${xerr.slice(0, 120)}]`;
    }
    report({ kind: 'request', status: res.status, method: req.method, url: target.origin + target.pathname, detail: '[sign-in trace]' + note });
  }
  // Report server errors, and 4xx answers to the app's own API calls
  // (fetch/XHR), with the start of the reply: that usually names the reason.
  const apiCall = req.mode !== 'navigate' && !req.destination;
  const frameLoad = req.destination === 'iframe' || req.destination === 'frame';
  if (res.status >= 500 || res.status === 431 || res.status === 413 || ((apiCall || frameLoad) && res.status >= 400)) {
    const why = res.headers.get('x-sj-error');
    let detail = why ? decodeURIComponent(why) : res.statusText;
    if (!why) {
      try {
        const body = (await res.clone().text()).replace(/\s+/g, ' ').trim();
        if (body) detail += ' \u2014 ' + body.slice(0, 240);
      } catch { /* unreadable body */ }
      const hints = ['www-authenticate', 'x-err', 'x-error', 'ms-cv', 'x-ms-error-code'];
      for (const h of hints) { const v = res.headers.get(h); if (v) detail += ` [${h}: ${v.slice(0, 120)}]`; }
    }
    report({ kind: 'request', status: res.status, method: req.method, url: target.href, detail });
  }

  const loc = res.headers.get('x-sj-location');
  if (loc) {
    const st = Number(res.headers.get('x-sj-status'));
    return Response.redirect(PREFIX + new URL(loc, target).href, REDIRECTS.has(st) ? st : 302);
  }

  const out = new Headers(res.headers);
  for (const k of [...out.keys()]) if (k.startsWith('x-sj-')) out.delete(k);
  // The browser already decoded the body, so the encoding and the encoded
  // length no longer apply. Some apps (Xbox's HTTP client) treat a body with
  // neither Content-Length nor Content-Type as empty, so a correct length is
  // put back below wherever it can be known.
  const wasEncoded = !!out.get('content-encoding');
  const origLength = out.get('content-length');
  out.delete('content-encoding');
  out.delete('content-length');
  const meta = { status: res.status, statusText: res.statusText, headers: out };

  if (NULL_BODY.has(res.status) || req.method === 'HEAD') return new Response(null, meta);

  const type = (out.get('content-type') || '').toLowerCase();
  const dest = req.destination;
  let kind = null;
  if (type.includes('text/html') && (req.mode === 'navigate' || ['document', 'iframe', 'frame', 'embed', 'object'].includes(dest))) kind = 'html';
  else if (['script', 'worker', 'sharedworker'].includes(dest)) kind = 'js';
  if (!kind) {
    if (!out.has('content-type')) {
      // Typically a small API reply (e.g. Xbox's endpoint directory):
      // buffer it so the exact decoded length can be given.
      const buf = await res.arrayBuffer();
      out.set('content-length', String(buf.byteLength));
      return new Response(buf, meta);
    }
    if (origLength != null && !wasEncoded) out.set('content-length', origLength);
    return new Response(res.body, meta);
  }

  const charset = (/charset=["']?([^;"']+)/.exec(type) || [])[1] || 'utf-8';
  let decoder;
  try { decoder = new TextDecoder(charset); } catch { decoder = new TextDecoder('utf-8'); }
  const text = decoder.decode(await res.arrayBuffer());

  if (kind === 'html') {
    out.set('content-type', 'text/html; charset=utf-8');
    return new Response(self.SJ.rewriteHtml(text, target.href, { inject: inject(target) }), meta);
  }
  let js = self.SJ.rewriteJs(text);
  if (dest === 'worker' || dest === 'sharedworker') js = PRELUDE + js;
  if (/javascript|ecmascript/.test(type)) out.set('content-type', 'text/javascript; charset=utf-8');
  return new Response(js, meta);
}
